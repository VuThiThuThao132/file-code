package data;

public class ItemList {

    Item list[];
    int numOfItem;
    final int Max = 100;
    // tạo mảng, biến đếm cho mảng 
    public ItemList() {
        list = new Item[Max];
        numOfItem = 0;
    }
// thêm sp
    public boolean addItem(Item item) {
        if (item == null || numOfItem >= Max) {
            return false;
        }
        list[numOfItem] = item;
        numOfItem++;
        return true;
    }

    //in thông tin các sản phẩm
    public void displayAll() {
        if (numOfItem == 0) {  
            System.out.println("the list is null! ");
        }
        for (int i = 0; i < numOfItem; i++) {
            System.out.println("----------"+" Item " +i+ " ----------");
            list[i].output();
        }
    }

    //tìm sản phẩm theo tên người tạo, trả về object tức trả về full chuỗi, theo to string
    public Item findItem(String creator) {
        for (int i = 0; i < numOfItem; i++) {
            if (list[i].getCreator().equals(creator)) {
                return list[i];
            }
        }
        return null;
    }

    //cập nhật thông tin theo số vị trí trong mảng 
    public boolean updateItemByIndex(int index) {
        if (index >= 0 && index < numOfItem) {
                list[index].input();
            return true;
        }
        return false;
    }

    //xóa 1 sp trong mảng bẳng cách đấy các sản phẩm đằng sau lên
    public boolean removeItem(int index) {
        if (index >= 0 && index < numOfItem) {
            for (int j = 0; j < numOfItem; j++) {
                list[j] = list[j + 1];
            }
            numOfItem--;
            return true;
        }
        return false;
    }

    //in ra các sp theo tên đặc trưng
    public void outputByName(String type) {
        switch (type) {
            case "Vase":
                for (int i = 0; i < numOfItem; i++) {
                    if (list[i] instanceof Vase) {
                        Item arr;
                        System.out.println(list[i]);
                    }
                }   break;
            case "Statue":
                for (int i = 0; i < numOfItem; i++) {
                    if (list[i] instanceof Statue) {
                        System.out.println(list[i]);
                    }
                }   break;
            case "Paintoing":
                for (int i = 0; i < numOfItem; i++) {
                    if (list[i] instanceof Painting) {
                        System.out.println(list[i]);
                    }
                }   break; 
            
        }
        

    }
    //sắp xếp mảng theo thứ tự tăng dần của value
    public void sortItem() {
         for(int i=0; i< numOfItem; i++){
            for(int j=numOfItem-1; j>i ;j--){
                if( list[j].getValue()< list[j-1].getValue()){
                     Item tmp=list[j];
                     list[j]=list[j-1];
                     list[j-1]=tmp;
                 }
            }
        }
    }
}
