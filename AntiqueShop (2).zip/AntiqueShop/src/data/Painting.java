
package data;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Painting extends Item {
    private int height;
    private int weight;
    private boolean isWatercolour;
    private boolean isFramed;
    
    public Painting() {
        
    }
    public Painting(int height, int weight, boolean isWatercolour, boolean isFramed, int value, String creator) {
        super(value, creator);
        this.height = height;
        this.weight = weight;
        this.isWatercolour = isWatercolour;
        this.isFramed = isFramed;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public boolean isIsWatercolour() {
        return isWatercolour;
    }

    public void setIsWatercolour(boolean isWatercolour) {
        this.isWatercolour = isWatercolour;
    }

    public boolean isIsFramed() {
        return isFramed;
    }

    public void setIsFramed(boolean isFramed) {
        this.isFramed = isFramed;
    }
    
    @Override
    public void input() {
        super.input();
        boolean cont = true;
        String check;
        Scanner sc = new Scanner(System.in);
        do {            
            try {
                System.out.println("Input height(h>0): ");
                height = Integer.parseInt(sc.nextLine());
                System.out.println("Input weight(w>0): ");
                weight = Integer.parseInt(sc.nextLine());
                if(weight<=0 || height <=0) {
                    throw new Exception();
                }
                cont = false;
            } catch (Exception e) {
                System.out.println("Something wrong.Input again!");
                cont = true;
            
            }
        } while(cont == true);
          
        do{  
            try {
                System.out.println("Does it has waterclour?(true/false): ");
                isWatercolour = sc.nextBoolean();
                System.out.println("Does it has framed?(true/false): ");
                isFramed =  sc.nextBoolean();
                cont = false;
            } catch (Exception e) {
                System.out.println("It must be true or false!");
                sc.nextLine();
                cont = true;
            }
        }while(cont);
    }
    @Override
    public void output() {
        System.out.println("Painting: ");
        super.output();
        System.out.println("Height: "+height);
        System.out.println("Weight: "+weight);
        System.out.println("IsWatercolour: "+isWatercolour);
        System.out.println("IsFramed: "+isFramed);
    } 

    @Override
    public String toString() {
        return "Painting{" + "height=" + height + ", weight=" + weight + ", isWatercolour=" + isWatercolour + ", isFramed=" + isFramed + '}';
    }
    
}
