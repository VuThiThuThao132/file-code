
package data;

import java.util.Scanner;

public class Statue extends Item {
    private int weight;
    private String colour;
    
    public Statue() {
        
    } 

    public Statue(int weight, String colour, int value, String creator) {
        super(value, creator);
        this.weight = weight;
        this.colour = colour;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }
    
    @Override
    public void input() {
        super.input();
        Scanner sc = new Scanner(System.in);
        boolean cont = true;
        do {            
            try {
                System.out.println("Input weight(w>0): ");
                weight = Integer.parseInt(sc.nextLine());
                System.out.println("What is the colour ?");
                colour = sc.nextLine();
                if(weight < 0 || colour == null || colour.matches("\\s*|\\d*")) {
                    throw new Exception();
                }
                cont = false;
            } catch (Exception e) {
                System.out.println("Check again please!");
            }
        } while (cont == true);
    }
    
    @Override
    public void output() {
        System.out.println("Statue: ");
        super.output();
        System.out.println("Weight: "+weight);
        System.out.println("Colour: "+colour);
    }

   
    
}
