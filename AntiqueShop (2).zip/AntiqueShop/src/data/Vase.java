package data;

import java.util.Scanner;

public class Vase extends Item {

    private int height;
    private String material;

    public Vase() {

    }

    public Vase(int height, String material, int value, String creator) {
        super(value, creator);
        this.height = height;
        this.material = material;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    @Override
    public void input() {
        super.input();
        boolean cont = true;
        Scanner sc = new Scanner(System.in);
        do {
            try {
                System.out.println("Input height(h>0): ");
                height = Integer.parseInt(sc.nextLine());
                System.out.println("what is the material?");
                material = sc.nextLine();
                if (height < 0 || material == null || material.matches("\\s*|\\d*")) {
                    throw new Exception();
                }
                cont = false;
            } catch (Exception e) {
                System.out.println("Some thing wrong! Input again plz ");
            }
        } while (cont == true);
    }

    @Override
    public void output() {
        System.out.println("Vase:");
        super.output();
        System.out.println("Height: " + height);
        System.out.println("Material: " + material);
    }

}
