package stage;

import data.Item;
import data.ItemList;
import data.Painting;
import data.Statue;
import data.Vase;
import java.util.Scanner;

public class antiqueShop {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Item tmp = null;
        int choice = 0;
        int index;
        ItemList obj = new ItemList();
        do {
            System.out.println("1. add a new vase");
            System.out.println("2. add a new statue");
            System.out.println("3. add a new painting");
            System.out.println("4. display all items");
            System.out.println("5. find the items by the creator ");
            System.out.println("6. update the item by its index");
            System.out.println("7. remove the item by its index");
            System.out.println("8. display the list by name items ");
            System.out.println("9. sorts items in ascending order based on their values ");
            System.out.println("10. exit");
            System.out.println("input your choice:");
            choice = Integer.parseInt(sc.nextLine());
            switch (choice) {
                case 1:
                    tmp = new Vase();
                    tmp.input();
                    if (obj.addItem(tmp)) {
                        System.out.println("Added");
                    }
                    break;
                case 2:
                    tmp = new Statue();
                    tmp.input();
                    if (obj.addItem(tmp)) {
                        System.out.println("Added");
                    }
                    break;
                case 3:
                    tmp = new Painting();
                    tmp.input();
                    if (obj.addItem(tmp)) {
                        System.out.println("Added");
                    }
                    break;
                case 4:
                    obj.displayAll();
                    break;
                case 5:
                    String creator = " ";
//                    if (obj.addItem(tmp) == false) {
//                        System.out.println("Nothing in list!");
//                        break;
//                    }
                    do {
                        System.out.println("What name you want to find?");
                        creator = sc.nextLine();
                        if (creator.matches("\\s*|\\d*")) {
                            System.out.println("Invalid name!");
                        } else {
                            break;
                        }
                    } while (true);

                    if (obj.findItem(creator) == null) {
                        System.out.println("Sorry no name in list");
                    } else {
                        System.out.println("After found!");
                        System.out.println(obj.findItem(creator));//in ra toString của tìm tìm
                    }
                    break;
                case 6:
//                    if (obj.addItem(tmp) == false) {
//                        System.out.println("Nothing in list!");
//                        break;
//                    }
                    do {
                        try {
                            System.out.println("Input index you want to update:");
                            index = Integer.parseInt(sc.nextLine());
                            break;
                        } catch (Exception e) {
                            System.out.println("It must be a number!");
                        }
                    } while (true);
                    if(obj.updateItemByIndex(index)) {
                        System.out.println("Upadate sucess!");
                    }else {
                        System.out.println("Not sucess!");
                    }
                        
                    break;
                case 7:
//                    if (obj.addItem(tmp) == false) {
//                        System.out.println("Nothing in list!");
//                        break;
//                    }
                    do {
                        try {
                            System.out.println("Input index you want to remove:");
                            index = Integer.parseInt(sc.nextLine());
                            break;
                        } catch (Exception e) {
                            System.out.println("It must be a number!");
                        }
                    } while (true);
                    if (obj.removeItem(index)==true) {
                        System.out.println("Sory no index in list!");
                    } else {
                        obj.removeItem(index);
                        System.out.println("Success!");
                    }
                    break;
                case 8:
//                    if (obj.addItem(tmp) == false) {
//                        System.out.println("Nothing in list!");
//                        break;
//                    }
                    String type;
                    do {
                        System.out.println("What name of type want to find?");
                        type = sc.nextLine();
                        if (type.matches("\\s*|\\d*")) {
                            System.out.println("Invalid type!");
                        } else {
                            break;
                        }
                    } while (true);
                    if (type.matches("Vase") || type.matches("Statue") || type.matches("Painting")) {
                        obj.outputByName(type);
                    } else {
                        System.out.println("No name match!");
                    }
                    break;
                case 9:
                    System.out.println("After sort: ");
                    System.out.println("------------");
                    obj.sortItem();
                    obj.displayAll();
                    break;
                case 10:
                    System.out.println("Goodbye!");
                    break;
            }
        } while (choice <= 9);
    }
}
