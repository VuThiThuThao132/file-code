#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct SINHVIEN
{
  char hoten[40];
  char masv[10];
  float dtb;
}SV;

typedef struct NODE
{
  SV info;
  struct NODE *next;
}node;

void init(node &phead)
{
  phead=NULL;
}

void createSV(SV &sv)
{
  printf("\nHo va ten:");fflush(stdin);gets(sv.hoten); puts(sv.hoten);
  printf("\nMa so    : ");fflush(stdin);gets(sv.masv);
  float tb;
  printf("\nDiem TB  : ");scanf("%f,&tb");sv.dtb=tb;
}

node *createNO(SV sv)
{
  node *Node=new node;
  Node->info=sv;
  Node->next=NULL;
  return Node;
}

void insertFi(node *&phead,SV sv)
{
  node *p=createNO(sv);
  if(phead==NULL)
  {
    phead=p;
  }
  else
  {
    p->next=phead;
    phead=p;
  }
}

node *searchNE(node *phead,char s[40])
{
  node *p=phead;
  while(p!=NULL)
  {
    if(stricmp(p->info.hoten,s)==0)
      return p;
    p=p->next;
  }
  return NULL;
}

void insertEN(node *&phead,SV sv)
{
  node *p=phead;
  node *q=createNO(sv);
  if(phead==NULL)
  {
    phead=q;
  }
  while(p->next!=NULL)
    p=p->next;
  p->next=q;
}

void insertAF(node *&phead,SV sv,char s[40])
{

  node *q=searchNE(phead,s);
  if(q==NULL)
  {
    printf("\nKhong ton tai sinh vien %s\n",s);
    textcolor(RED);
    cprintf("khong the chen��");
  }
  else
  {
    printf("\nThem sinh vien: \n");
    createSV(sv);
    node *p=createNO(sv);
    p->next=q->next;
    q->next=p;
  }
}

void showNO(node *phead)
{
  SV sv=phead->info;
  printf("\nHo ten : %s",sv.hoten);
  printf("\nMa so  : %s",sv.masv);
  printf("\nDiem TB: %0.2f",sv.dtb);
}

void deleteFI(node *&phead)
{
  if(phead==NULL)
    printf("\nList rong.");
  else
  {
    node*p=phead;
    phead=phead->next;
    delete p;
  }
}

int countNO(node *phead)
{
  node *p=phead;
  int count=0;
  while(p!=NULL)
  {
    count++;
    p=p->next;
  }
  return count;
}

void showLI(node *phead)
{
  node *p=phead;
  if(p==NULL)
  {
    printf("\nList rong.");
    return;
  }
  while(p!=NULL)
  {
    showNO(p);
    p=p->next;
  }
}

int showcondition(node *phead,float d1,float d2)
{
  node *p=phead;
  int add=0;
  while(p!=NULL)
  {
    if(p->info.dtb>d1 && p->info.dtb    {
      showNO(p);
      add++;
    }
    p=p->next;
  }
  return (add>0)?add:0;
}

void swap(SV &sv1,SV &sv2)
{
  SV sv3=sv1;
  sv1=sv2;
  sv2=sv3;
}

void sortcode(node *phead)
{
  node *p=phead;
  while(p!=NULL)
  {
    node *q=phead;
    while(q!=NULL)
    {
      if(stricmp(q->info.masv,p->info.masv)>0)
        swap(q->info,p->info);
      q=q->next;
    }
    p=p->next;
  }
}

void main()
{
  SV sv;
  node *phead=NULL;
  int n;
  do{
    do{
      clrscr();
      textcolor(YELLOW);
      cprintf("�������MOI LUA CHON CHUC NANG��������");printf("\n");
      textcolor(WHITE);
      printf("\n\t1.Them sinh vien vao dau danh sach.");
      printf("\n\t2.Them sinh vien vao cuoi danh sach.");
      printf("\n\t3.Tim theo ten va chen sau.");
      printf("\n\t4.Xoa sinh vien dau danh sach.");
      printf("\n\t5.Dem so sinh vien trong danh sach.");
      printf("\n\t6.Tim sinh vien theo khoang diem.");
      printf("\n\t7.Sap xep sinh vien theo ma so.");
      printf("\n\t0.Thoat.");
      printf("\n\n");
      printf("\nList hien tai: \n");
      showLI(phead);printf("\n");
      cprintf("Nhap so tuong ung: ");
      scanf("%d",&n);
      if(n<0 || n>7)
        printf("nhap sai!\nXin nhap lai!");

    }while(n<0 || n>7);
    switch(n)
    {
      case 1:
        createSV(sv);
        insertFi(phead,sv);
        break;
      case 2:
        createSV(sv);
        insertEN(phead,sv);
        break;
      case 3:
        char s[40];
        printf("\nNhap ten sinh vien can tim: ");
        scanf("%s",s);
        insertAF(phead,sv,s);
        break;
      case 4:
        deleteFI(phead);
        break;
      case 5:
        int count=countNO(phead);
        if(count!=0)
          printf("\nSo sv hien tai: %d",count);
        else
          printf("\nDanh sach rong�.");
        break;
      case 6:
        int d1,d2;
        printf("\nTim sinh vien theo DK: ");
        printf("\nNhap khoang diem (d1->d2): ");
        scanf(�%d%d�,&d1,&d2);
        if(!showcondition(phead,d1,d2))
        printf("\nKhong tim thay!");
        break;
      case 7:
        sortcode(phead);
        break;
      case 0:
        break;
    }
    printf("\n");
    cprintf("Cap nhap lai: ");printf("\n");
    showLI(phead);
    getch();
  }while(n!=0);
  getch();
}
[/codes]

//Ca�ch 2:
//
//[codes=c]/*
//  Le Quoc Nam
//  Lop  10cth01
//  Compiler: C-free 4.0 pro, Windows 7 Home Premium x64 OA
//*/
//
//#include
//#include
//#include
//#define MAX 100
////�������������������������������-
//typedef struct sinhvien{
//  char masv[15];
//  char hoten[31];
//  float dtb;
//};
//
//typedef struct node{
//  sinhvien* data;
//  struct node *next;
//};
////�������������������������������-
//node *head;
//
//node *create(sinhvien *g){
//  node *p= new node;
//   if (p==NULL) return 0;
//  p->data=g;
//  p->next=NULL;
//  return p;
//}
////�������������������������������-
//sinhvien* createSV(){
//  sinhvien* sv=new sinhvien;
//  float temp;
//  fflush(stdin);
//  printf(�Nhap ma SV: �); gets(sv->masv);
//  printf(�Nhap ten: �); gets(sv->hoten);
//  printf(�Nhap diem tb: �); scanf(�%f�,&temp);
//  sv->dtb=temp;
//  return sv;
//}
////�������������������������������-
//void insertFirst(node *&head, sinhvien *g){
//  node *p= create(g);
//  if(head==NULL) head=p;
//  else
//  {  
//    p->next=head;
//    head=p;
//  }
//}
////�������������������������������-
//void insertEnd(node *&head, sinhvien *g){
//  node *p= create(g);
//  if(head==NULL)
//    head=p;
//  else
//  {  
//    node *temp=head;
//    while(temp->next!=NULL)
//      temp=temp->next;
//      temp->next=p;
//  }
//}
////�������������������������������-
//void xuat(node* head){
//  if(head==NULL)
//    printf(�Danh sach rong.\n�);
//  else
//    printf(�Danh sach SV la \n�);
//  for(node* p=head;p!=NULL;p=p->next)
//  {
//    printf(�Ma SV: %s�,p->data->masv);
//    printf(�\nHo ten: %s�,p->data->hoten);
//    printf(�\nDiem trung binh: %f�,p->data->dtb);
//    printf(�\n���������\n�);
//  }
//}
////�������������������������������-
//node* searchsv(node* phead){
//  char x[15];
//  printf(�Nhap ma so SV can tim: �);
//  fflush(stdin);
//  gets(x);
//  for(node*p=phead;p!=NULL;p=p->next)
//    if ((strcmp(p->data->masv,x)==0))
//      return p;
//  return NULL;
//}
////�������������������������������-
//void insertAfterX(node *&head, node *&p, sinhvien *g){
//  if(p==NULL) printf(�KHong the them�);
//  else
//  {
//    node *temp = create(g);
//    temp->next=p->next;
//    p->next=temp;
//  }
//}
////�������������������������������-
//void deleteFirst(node *&head){
//  if(head==NULL)
//    printf(�Rong, ko the xoa�);
//  else
//  {
//    node* p=head;
//    head = head->next;
//    delete p;
//  }
//}
////�������������������������������-
//int tongSV(node* head, sinhvien *g){
//  int s=0;
//  for(node* p=head;p!=NULL;p=p->next)
//    s++;
//  return s;
//}
////�������������������������������-
//int chckdiem(node* head){
//  for(node*p=head; p!=NULL; p=p->next)
//    if(p->data->dtb>5 && p->data->dtb<8)
//      return 1;
//  return 0;
//}
//
//void svdtb(node *head){
//  for(node *p=head; p!=NULL; p=p->next)
//  {
//    if(p->data->dtb>5 && p->data->dtb<8)
//    {  
//      printf(�Ma SV: %s�,p->data->masv);
//      printf(�\nHo ten: %s�,p->data->hoten);
//      printf(�\nDiem trung binh: %f�,p->data->dtb);
//      printf(�\n���������\n�);
//
//    }
//  }
//      
//}
////�������������������������������-
//void swap(sinhvien* &a, sinhvien* &b){
//  sinhvien* tem = a;
//  a=b;
//  b=tem;
//}
//
//void sapxep(node *head){
//  for(node* p=head;p!=NULL;p=p->next)
//    for(node* q=p->next;q!=NULL;q=q->next)
//      if(stricmp(p->data->masv , q->data->masv)>0)
//        swap(p->data,q->data);
//}
////�������������������������������-
//void main()
//{
//  int x, n;
//  int chon, tt=1, s;
//  sinhvien *g;
//  do{
//    printf(�\n�);
//    printf(���������������������\n�);
//    printf(�\nHay chon chuc nang can thuc hien: \n�);
//    printf(�0. Thoat\n�);
//    printf(�1. Them mot SV vao dau\n�);
//    printf(�2. Them mot SV vao cuoi\n�);
//    printf(�3. Tim SV, sau do chen 1 SV vao sau SV do\n�);
//    printf(�4. Xoa SV dau\n�);
//    printf(�5. Tong so SV la bao nhieu\n�);
//    printf(�6. Xuat ra danh sach\n�);
//    printf(�7. Xuat ra SV co 5    printf(�8. Xep tang them ma SV\n�);
//    printf(���������������������\n�);
//    scanf(�%d�, &chon);
//  switch(chon)
//  {
//    case 1:
//    {
//      printf(�Nhap thong tin 1 Sv can them dau\n�);
//      g=createSV();
//      insertFirst(head,g);
//      printf(�Danh sach sau khi them la:\n�);
//      xuat(head);
//      break;
//    }
//    case 2:
//    {
//      printf(�Nhap thong tin 1 Sv can them cuoi\n�);
//      g=createSV();
//      insertEnd(head, g);
//      printf(�Danh sach sau khi them la:\n�);
//      xuat(head);
//      break;
//    }
//    case 3:
//    {
//      node *p=searchsv(head);
//      if(p==NULL) printf(�Ko tim thay!�);
//      else
//      {
//        printf(�Da tim thay, nhap thong tin 1 SV can them:\n�);
//        g=createSV();
//        insertAfterX(head, p,g);
//        printf(�Danh sach sau khi them la:\n�);
//        xuat(head);
//        break;
//      }
//    }
//    case 4:
//    {
//      deleteFirst(head);
//      printf(�Da xoa SV dau danh sach\n�);
//      printf(�Danh sach sau khi xoa la:\n�);
//      xuat(head);
//      break;
//    }
//    case 5:
//    {
//      printf(�Tong so SV co trong danh sach %d\n�, tongSV(head, g));
//      break;
//    }
//    case 6:
//    {  
//      xuat(head);
//      break;
//    }
//    case 7:
//    {
//      int ch=chckdiem(head);
//      if(ch==1)
//        {
//        printf(�SV co 5        svdtb(head);
//        }
//      else
//        printf(�Ko co SV nao co 5      
//      break;
//    }
//    case 8:
//    {
//      printf(�Danh sach sau khi sap xep: \n�);
//      sapxep(head);
//      xuat(head);
//      break;
//    }
//    case 0:
//    {
//      tt=0;
//      break;
//    }
//  };
//  }while(tt==1);
//  getch();
//}
////�������������������������������-[/codes]
//
struct SinhVien
{
	char hoten[30],MSSV[20],lop[10];
	float DiemNNLT,Tinhoc,ToanA1;
	int namsinh;
};
typedef SinhVien sinhvien;
Khai b�o c�c h�m c?n s? d?ng

void nhap1sv(sinhvien &sv);
void xuat1sv(sinhvien sv);
float DiemTB(sinhvien sv);
char* XepLoai(sinhvien sv);
Vi?t h�m nh?p

void nhap1sv(sinhvien &sv)
{
	printf("\nNhap vao ho va ten sinh vien: ");
	fflush(stdin);
	gets(sv.hoten);
	printf("Nhap vao ma so sinh vien: ");
	fflush(stdin);
	gets(sv.MSSV);
	printf("Nhap vao lop cua sinh vien ");
	fflush(stdin);
	gets(sv.lop);
	printf("\nNam sinh cua sinh vien: ");
	scanf("%d",&sv.namsinh);
	do
	{
		printf("\nNhap vao diem mon NNLT ");
		scanf("%f",&sv.DiemNNLT);
		if(sv.DiemNNLT>10 || sv.DiemNNLT<0)
			printf("\nDiem tu 0 den 10!\nVui long kiem tra lai");
	}while(sv.DiemNNLT < 0 || sv.DiemNNLT > 10);
	do
	{
		printf("\nNhap vao diem mon tin hoc ");
		scanf("%f",&sv.Tinhoc);
		if(sv.Tinhoc > 10 || sv.Tinhoc < 0)
			printf("\nDiem tu 0 den 10!\nVui long kiem tra lai");
	}while(sv.Tinhoc > 10 || sv.Tinhoc < 0);
	do
	{
		printf("\nNhap vao diem mon toan A1 ");
		scanf("%f",&sv.ToanA1);
		if(sv.ToanA1 > 10 || sv.ToanA1 < 0)
			printf("\nDiem tu 0 den 10!\nVui long kiem tra lai");
	}while(sv.ToanA1 < 0 || sv.ToanA1 > 10);
}
Vi?t h�m xu?t

void xuat1sv(sinhvien sv)
{
	printf("\nHo va ten sinh vien: %s",sv.hoten);
	printf("\nMa so sinh vien: %s",sv.MSSV);
	printf("\nLop hoc: %s",sv.lop);
	printf("\nNam sinh: %d",sv.namsinh);
	printf("\nDiem mon NNLT: %8.2f",sv.DiemNNLT);
	printf("\nDiem mon tin hoc: %8.2f",sv.Tinhoc);
	printf("\nDiem mon toan A1: %8.2f",sv.ToanA1);
	printf("\nDiem trung binh: %8.2f",DiemTB(sv));
	printf("\nXep loai: %s",XepLoai(sv));
}
Vi?t h�m t�nh trung b�nh

float DiemTB(sinhvien sv)
{
	float tb;
	tb=(sv.DiemNNLT +sv.Tinhoc +sv.ToanA1)/3;
	return tb;
}
Vi?t h�m x?p lo?i

char*XepLoai(sinhvien sv)
{
	float tb=DiemTB(sv);
	if(tb>=9)
		return "Xuat sac";
	else if(tb>=8 && tb<9)
		return "Gioi";
	else if(tb>=6.5 && tb<8)
		return "Kha";
	else if(tb>=5 && tb<6.5)
			return "Trung binh";
	else
		return "Yeu";
}
Vi?t h�m main

void main()
{
	sinhvien sv;
	nhap1sv(sv);
	xuat1sv(sv);
	getch();
}
