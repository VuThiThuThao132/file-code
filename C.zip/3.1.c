#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int nhapn() {
int n= 0;
	do {
		printf("Enter a positive integer (0 exit): ");
		scanf("%d", &n);
	} while (n < 0);
	return n;
}
void songduong(int n) {
	int s = 0;
	do {
		if (n == 0) {
			break;
		}
		else {
			int m = n;
			while (m > 0) {
				s = s * 1 + m % 10;
				m /= 10;
			}
			printf("The sum of its decimal digits: %d\n", s);
		}
		
	} while (s>n);
}

int main() {
	int n = nhapn();
	songduong(n);
	 while (n!=0){
		n=nhapn();
		songduong(n);
	} 
	printf("Goodbye!");
	return 0;
}
