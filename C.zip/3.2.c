#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    double n;
    do{
    printf("Enter a positive integer (0 exit): ");
    scanf("%lf",&n);
    if(n<0){
	printf("Enter a positive integer (0 exit): ");
    scanf("%lf",&n);}
    if(n==0){
	break;
	}
int checkFibonacci(char c);
	    double f=1;
        double f1=0;
        double f2=0;
            if(n>0){
        double i=0;
        for(i=0;i<=n;i++)
        {
           
            f=f+f1;
            f1=f2;
            f2=f;
            if (f==n){
			printf("%.0lf is Fibonacci",n);
                break;
			}
            else if((f+1)!=n && (f+1)>n){
			printf("%.0lf isn't Fibonacci",n);
			break;
			}
            
        }
            printf("\n");
        }
    
    }
    while (n!=0);
    printf("Goodbye!");
    return 0;
}
