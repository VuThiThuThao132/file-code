#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
#include <stdio.h>
void Input(int* n)
{
	do
	{
		printf("Enter value of n: ");
		scanf("%d",n);
	}while ((*n)<0);
}
void Fibonacci(int n)
{
	long long int F0 = 0, F1 = 0,F=1;
	int count = 0;
	while(count < n)
	{
			printf("%lld   ",F);
			count ++;
			if (count%5==0) 
			printf("\n");
			F0=F1;
			F1=F;
			F=F0+F1;
	}
	printf("\n");	
}
void loop()
{
	int n;
	while(1)
	{
		Input(&n);
		if (n==0) 
		{
			printf("Goodbye!");
			break;
		}
		Fibonacci(n);
	}
}
int main()
{
	loop();
	return 0;
}

