#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int fix (char c);
double clam(double a, double b, double n);
int main(int argc, char *argv[]){
	char c;
	double a,b,n;
	do{
		printf("Enter a: ");
		scanf("%lf",&a);
		printf("Enter b: ");
		scanf("%lf",&b);
		printf("Enter n: ");
		scanf("%lf",&n);
		getchar();
		printf("F=%0.2lf",clam(a,b,n));
		do{
			printf("\nDo you want to continue counting? (n=no/y=yes): ");	
			scanf("%c",&c);
			fflush(stdin);
			printf("\n");
		}while(fix (c)!=1);
	}while(c=='y');
	if(c=='n'){
		printf("Goodbye !");
	}
	return 0;
}
double clam(double a, double b, double n){
	double F,F1=0;
	double j=n;
	for(j=0;j<=n;j++){
		F=(a+j)/(b+j);
		F1+=F;
	}
	return F1;
}
int fix (char c){
	int check;
	if(c=='y'||c=='n'){
		check=1;
	}else{
		check=0;
	}
	return check;		
}	
 
