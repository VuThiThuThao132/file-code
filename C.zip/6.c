#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define MAX 100
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void addValue(int a[], int value, int*pn);
int search(int x,int a[],int n);
int deleOne(int pos, int *a, int *pn);
int deleAll(int x,int*a, int*pn);
void printArray(int *a, int n);
void printEven(int a[],int n);
int printMax(int a[],int n);
void printRage(int a[],int n);
void bubbleSort (int a[],int );
int checkFull (int a[], int);
int checkEmpty(int a[], int);
int main(int argc, char *argv[]) {
	int a[100];
	 int i,n = 0,choice, value;
   do{
    printf("======================\n");
    printf("\n**MENU**\n1- Add a value\n2- search a value\n3- Remove the first existence of a value\n4- Remove all existence of a value\n5- Print out the array\n6- Print out even value in array\n7- Print out the maximum value of the array\n8- Print out value in a range\n9-  Print out the array in ascending order\n0- End.\nYour choice: ");
    scanf("%d",&choice);
    switch(choice){
    	case 0:
    		   printf("Goodbye!");
    		   break;
    	case 1:
    			if(checkFull(a,n)) printf("\nThe array is full.\n");
			    else addValue(a, value,&n);
    			break;
    	case 2:
               	if(checkEmpty(a,n)) printf("\nThe array is empty.\n");
				else {
			    	printf("\nEnter integer number: ");
					scanf("%d", &value);
					int pos=search(value, a, n);
					if(pos<0) printf("Not found\n");
				}
    		break;
    	case 3:
    		if (checkEmpty(a,n)) printf("\nSorry ! the array is empty.\n");
				else {
					printf ("\nEnter integer number:");
					scanf("%d", &value);				
					if(linearSearch(value, &a, n) == -1)
				    printf("%d not exist in aray.\n", value);
					
			else if	(linearSearch(value,&a,n) != -1)	
			        {
					deleOne(value,a,&n);
					printf("Array after remove %d: ",value);
					printArray(a,n);
					printf("\n");
			    }
			}		
			
    	     	break;
    	case 4:
    		if (checkEmpty(a,n)) printf("\nSorry ! the array is empty.\n");
				else {
					printf ("Enter integer number:");
					scanf ("%d", &value);
				deleAll(value,a,&n);
			   printf("\n");
			   }					
    		break;
    	case 5:
    		   	if (checkEmpty(a,n)) printf("\nSorry ! the array is empty.\n");
    		   	else
				     printArray(a,n);
                printf("\n");
    		break;
    	case 6:
    		  	if (checkEmpty(a,n)) printf("\nSorry ! the array is empty.\n");
    	        else printEven(a,n);  
    		break;
    	case 7:
    		  	if (checkEmpty(a,n)) printf("\nSorry ! the array is empty.\n");
    		  	else{
		        printMax(a,n);
        	    }
    		break;
    	case 8:
    		  	if (checkEmpty(a,n)) printf("\nSorry ! the array is empty.\n");
                else printRage(a,n);
    		break;
        case 9:
        	   	if (checkEmpty(a,n)) printf("\nSorry ! the array is empty.\n");
                else bubbleSort(a,n);
        	break;
    	default:
						printf("Check your choice again!!!\n");
          }
		
	} while (choice !=0);
	getchar();
	return 0;
}		   
int checkFull(int *a, int n) {
	return n == MAX;
}
int checkEmpty(int *a, int n) {
	return n==0;
}
//add a value
void addValue(int a[], int value, int*pn){
	int check;
	char after;
	do{
		fflush(stdin);
		printf("Enter integer number: ");
		check=scanf("%d%c", &value, &after);
	}while(check==0 || after != '\n');
		a[*pn] = value;
		(*pn)++;
		printf("Add success.\n");
}
// search a value 
int search(int x,int a[],int n){
	int check=1,i;
	for( i=0; i<n; i++){
		if(a[i]==x){
			printf("index %d\n",i);
			check=0;
		}
	}
	if(check==1){
		printf("%d not exit in array\n",x);
	}
}

//Remove the first existence of a value
int deleOne(int x, int *a, int *pn){
	int i,n,p;
	p=linearSearch(x,a,*pn);
	if (p>=0)
	   for (i = p;i < *pn - 1;i++)
         a[i]  = a[i+1];
        (*pn)--;
 }    
int linearSearch(int x, int a[],int slpt){
	int pos,i;
	pos = -1;
	for(i=0; i < slpt && pos < 0; i++)
	 if (a[i]==x)
	  pos = i;
	return pos;
}
//Remove the all existence of a value
int deleAll(int x,int*a, int*pn){
	int result=0;
	int i,j;
	for (i=(*pn)-1;i>=0;i--)
	 if(a[i]==x) {
	 result=1;
	 for (j=i;j<(*pn)-1;j++) a[j]=a[j+1];
	 (*pn)--;
	}
	if(result == 1){
	printf("Array after remove %d: ",x);
	for(i=0; i<*pn; i++) printf("%d ", a[i]);}
	else printf("%d not exit in array!\n", x);	
}
//print in a array
void printArray(int *a, int n) {
	int i;
	for(i=0; i<n; i++) printf("%5d ", a[i]);
}

//even
void printEven(int a[],int n){
	int i, count = 0;
	printf("Even values: ");
	for(i = 0; i < n; i++) if(a[i] % 2 == 0) printf("%d ", a[i]); else count++;
	if(count == n) printf("Not found!\n"); else printf("\n");
}

//maximum value
int printMax(int a[],int n){
	int i; 
	int max=a[0];
	for(i=0;i<n;i++){
		if(a[i]>max)
		max= a[i];
		}
    printf("Max value in array: %d\n",max);
}
//Print out values in a range
void printRage(int a[],int n){
	int i, x, y,check, count=0;
	char after;
	do{
		fflush(stdin);
		printf("Enter smallest number of rage: ");
		check=scanf("%d%c",&x,&after);
		printf("Enter largest number of rage: ");
		check=scanf("%d%c",&y,&after);
	}while (check==0||after!='\n');
	for (i=0;i<n;i++)
	 if (a[i]>= x && a[i]<=y)
	 printf("%5d",a[i]);
	 else count++;
	 if(count == n)
      printf("No value!");
      printf("\n");
}
 //Print out the array in ascending order
void bubbleSort(int a[],int n){
	int t,i,j,check=0;
	int x[MAX];
	for(i=0; i<n;i++)
	    x[i]=a[i];
	for(i=0;i<n-1;i++){
		for (j=0;j<n-1-i;j++){
			if(x[j]>x[j+1]){
				check=1;
				t=x[j];
				x[j]=x[j+1];
				x[j+1]=t;
				}
		}
	}if(check==0)
	printf("The array was sorted before: ");
	else printf("after sort: ");
	for(i=0;i<n;i++)
	printf("%d ",x[i]);
	printf("\n");
}	
