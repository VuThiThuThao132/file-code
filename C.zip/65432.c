#include <stdio.h>
#include <stdlib.h>
#define MAX 100
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void inputMatrix(int a[][100], int m, int n){
	 for(int i = 0; i < m; i++)
        for(int j = 0; j < n; j++){
	    	printf("a[%d][%d] = ", i, j);
	    	scanf("%d", &a[i][j]);
	        }
	    }
void outputMatrix(int a[][20], int m, int n){
      for(int i =0; i < m; i++){
	    for(int j = 0; j < m; j++)
	    	printf("%d\t", a[i][j]);
	    }
	}
int MaxArray(int a[][20], int m, int n){
	int max = a[0][0];
	for(int i =0; i < m; i++)
	    for(int j = 0; j < m; j++)
	     if(a[i][j] > max)
	     max = a[i][j];
	     return max;
 }
int sumEven(int a[][20], int m, int n){
	   int sum = 0;
	   for(int i = 0; i < m, i++)
	      for(int j = 0; j < n, i++)
	       (a[i][j]%2 == 0)
	         sum += a[i][j];
	return sum;
int primeMatrix(int a[][20], int m, int n){
    int count = 0;
	for(int i = 0; i < m; i++)
	    for(int j = 0; j < n; j++)
		  if(isPrime(a[i][j])) 
		   count++;
		return count;
	    	 
