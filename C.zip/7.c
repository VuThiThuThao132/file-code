#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#define MAX 100
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void MENU();
int checkFull( int n);
int checkEmpty(int n);
char* lTrim(char s[]);
char* rTrim(char s[]);
char* trim(char s[]);
char* nameStr(char s[]);
void addList(char list[][MAX],float score[],int* n);
void printList(char list[][MAX],float score[], int n);
void searchByName(char list[MAX][MAX],float score[], int n);
void searchByScore(char list[][MAX],float score[],int n);
void sortByScore(char list[][MAX], float score[], int n);
void sortByName(char list[][MAX], float score[], int n);
void removestudent(char list[][MAX], int* n);
int main(int argc, char *argv[]){
	int n=0, choice;
	char list[MAX][MAX];
    float score[MAX];
	do{
		fflush(stdin);
		MENU();
		printf("\nYour choice: ");
		scanf("%d", &choice);
		switch(choice){
			case 1: 
					if(checkFull(n)) printf("\nThe array is full.\n");
					else{
					addList(list,score, &n);					
					printf("\nAdded!\n");}
			       break;
			case 2:
				    if(checkEmpty(n)) printf("\nThe array is empty.\n");
			    	else
			    	    printf("list: \n");
				        printList(list,score,n);   
				   break;
			case 3:
			       	if(checkEmpty(n)) printf("\nThe array is empty.\n");
				    else searchByName(list, score, n);
				    break;
			case 4:
				    if(checkEmpty(n)) printf("\nThe array is empty.\n");
				    else searchByScore(list, score, n);
				    break;
		    case 5: 
		           if(checkEmpty(n)) printf("\nThe array is empty.\n");
				    else
		           printf("After sorting: \n");
		           sortByName(list, score, n);
			       break;  
			case 6: 
		           if(checkEmpty(n)) printf("\nThe array is empty.\n");
				    else
		           printf("After sorting: \n");
		           sortByScore(list, score, n);
			       break; 
		    case 7: 
		           if(checkEmpty(n)) printf("\nThe array is empty.\n");
				    else
		           printf("After removing: \n");
		           removeStudent(list,&n);
			       break;   
		}
	}while(choice != 0);
	 printf("Goodbye!");
	return 0;
}
void MENU(){
        printf("\n==========================MENU==========================");
		printf("\n|1- Add a student into the list                         |");
	    printf("\n|2- Print out the all list                              |");
		printf("\n|3- Search student by name                              |");
		printf("\n|4- Search student by score                             |");                            
		printf("\n|5- Sort the student list by alphabetic order by name   |");
		printf("\n|6- Sort the student list in ascenting order by score   |");
		printf("\n|7- removed student                                     |");
		printf("\n|0- Exist                                               |");
		printf("\n=========================================================\n");
}
int checkFull(int n)
{
	return n == MAX;
}

int checkEmpty(int n)
{
	return n == 0;
}

char* lTrim (char s[])
{
	int i = 0;
	while (s[i] == ' ')	i++;
	if (i > 0) strcpy(&s[0], &s[i]);
	return s;
}

char* rTrim (char s[])
{
	int i = strlen(s) - 1;
	while (s[i] == ' ') i--;
	s[i+1] = '\0';
	return s;
}

char* trim (char s[])
{
	rTrim(lTrim(s));
	char *ptr = strstr(s, "  ");
	while (ptr != NULL)
	{
		strcpy(ptr, ptr + 1);
		ptr = strstr(s, "  ");
	}
	return s;
}

char* nameStr(char s[]){
	trim(s);
	strlwr(s);
	int L = strlen(s);
	int i;
	for(i = 0; i < L; i++)
	   if(i == 0 || (i > 0 && s[i-1] == ' ')) 
	     s[i] = toupper(s[i]);
}
//add
void addList(char list[][MAX],float score[],int* n){
	
	printf("Enter name: ");
	fflush(stdin);
	gets(list[*n]);
	nameStr(list[*n]);
	
	printf("Enter score: ");
	scanf("%f", &score[*n]);
//	score[*n] = getNumber(0,100);	
	(*n)++;
}
//print
void printList(char list[][MAX],float score[], int n){
	for(int i=0;i<n;i++){
		printf("\n%15s",list[i]);
		printf("%15.2f",score[i]);
	}
}
//search by name
void searchByName(char list[MAX][MAX],float score[], int n){
	int flag = 1;
	char x[MAX];
	printf("Enter name to search: ");
	fflush(stdin);
	gets(x);
	nameStr(x);
	for(int i = 0; i < n; i++){
	    char* ptr = strstr(list[i],x);
	    if(ptr != NULL){
	    	puts(list[i]);
	    	flag = 0;
		}
    }
     if(flag == 1)
        printf("Nobody in class have name %s!");
}
//search by Score
void searchByScore(char list[][MAX],float score[],int n){
	float num;
	int mark=0;
	printf("Enter score:");
	scanf("%f",&num);
	int i;
	for(i=n-1;i>=0;i--){
		if(num==score[i]){
			printf("\n%15s have %0.2f",list[i],num);
			mark=1;
		}
	}
	if(mark==0){
		printf("Nobody in class have %0.2f score!",num);
	}
}
//sortByScore
void sortByScore(char list[][MAX], float score[], int n){
    char list2[MAX][MAX];
    float score2[MAX];
    char x[MAX];
    float num;
    int i,j;
    for(i=0;i<n;i++){
     	strcpy(list2[i],list[i]);
     	score2[i]=score[i];
      }
     for(i=0;i<n-1;i++){
      for(j=n-1;j>i;j--){
 	   	if(score2[j]<score2[j-1]){
 			strcpy(x,list2[j]);
 			strcpy(list2[j],list2[j-1]);
 			strcpy(list2[j-1],x);
 			
 			num=score2[j];
 			score2[j]=score2[j-1];
 			score2[j-1]=num;
		 }
	 }
 }
     printList(list2,score2,n);
}
//sortByName
void sortByName(char list[][MAX], float score[], int n){
	int i, j;
	char list2[MAX][MAX];
	float score2[MAX];
	char t[MAX];
	float t_number;
	//copy
	for(i = 0; i < n; i++){
		strcpy(list2[i],list[i]);
		score2[i] = score[i];
	}
	for(i = 0; i < n - 1; i++){
		for(j = n - 1; j > i; j--)
		 if(strcmp(list2[j - 1], list2[j]) > 0){
		 	strcpy(t,list2[j]);
		 	strcpy(list2[j], list2[j-1]);
		 	strcpy(list2[j-1],t);
		 	
		 	t_number = score2[j];
		 	score2[j] = score[j-1];
		 	score2[j-1] = t_number;
		 }
	}
	
	printList(list2, score2, n);
void remove(char list[][MAX], int* n){
	int i, j;
	char list2[MAX][MAX];
	int flag = 0;
	char x[MAX];
	printf("Enter name remove: ");
	fflush(stdin);
	gets(x);
	nameStr(x);
	for( i= 0; i < *n; i++){
		if(strcmp(list2[i],x)==0){
		 for(j = i; j < *n; j++)
		         list2[j] = list[j + 1];
		    (*n)--;
		    i--;
		    flag = 1;
		}
	}
	if(flag == 1){
		printf("After remove: \n");
		printArray(list, *n);
	}else 
	printf("Name not exit.\n"); 
}
