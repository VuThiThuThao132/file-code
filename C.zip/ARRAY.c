#include <stdio.h>
#include <stdlib.h>
#define MAX 100
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void menu();
void inputArray(int a[],int n);
void printArray(int a[],int n);
void printEven(int a[],int n);
int printMax(int a[],int n);
void clear();
int getint(int min, int max);
int main(int argc, char *argv[]) {
 int n, choice;
 int a[MAX];
 do{
 	menu();
 	printf("\nYour choice: ");
 	scanf("%d",&choice);
 	switch(choice){
 		case 1:
 			   printf("Enter size: ");
 			   n= getint(1,100);
 			   inputArray(a,n);
 			   break;
 		case 2:
 			   printArray(a,n);
 			   break;
 	    case 3:
 	           printEven(a,n);
 	           break;
 	    case 4:
 	    	   printf("Max value: %d",printMax(a,n));
 	    	   break;
 	}while (choice !=0);
 	printf("Goodbye!");
 	return 0;
}
void menu(){
	int menu;
	printf("\nMenu\n0- Exit\n1- Input array\n2- Print out array\n3- Even value in array\n4- Max value");
    } 
void inputArray(int a[], int n){
	for (int i=0;i<n;i++);{
	     printf("a[%d]= ",i);
	     scanf("%d",&a[i]);
  }
}
void printArray(int* b, int n){
	printf("Array: ");
	for(int i=0;i<n;i++)
	printf("%5d",b[i]);
}
void printfEven(int a[],int n){
	printf("Even value: ");
	for (int i=0;i<n;i++){
		if (a[i]%2==0)
		    printf("%5d",a[i]);
	}
}

