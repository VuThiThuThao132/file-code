#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int sumDivisors(int n ){
	int s=0;
	int i;
	for( i=1; i<n; i++){
		if(n%i==0){
			printf("%d\t",i);
			s += i;
		}
	}
	return s;
 }
int main(int argc, char *argv[]) {
	int n;
	do{
		printf("Enter a positive integer: ");
		scanf("%d",&n);
	}while (n<1);
	
	printf("\nSum: %d",sumDivisors(n));
	
 return 0;
 }
	

