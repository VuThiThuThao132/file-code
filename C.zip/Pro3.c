#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int isPrime(int n)
{ int result=1,i;
  for (i=2;i*i<=n && result==1; i++)
     if (n%i==0) result=0;
     return result;
}
void print_n_Primes (int n)
{ int count = 0;
  int value = 2;
  while (count<n)
  {if (isPrime(value)==1)
      {  printf("%d ", value);
         count++;
     }
     value++;
  }
}
int main(int argc, char *argv[]) {
	int n;
	do{
	printf("Enter n: ");
	scanf("%d",&n);}while(n<=0);
		printf("Result of the first %d primes: \n ",n);
	print_n_Primes(n);
	getchar();
	getchar();
	
	return 0;
}
