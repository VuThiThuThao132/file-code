#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#define MAX 100
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void MENU();
int checkFull( int n);
int checkEmpty(int n);
char* lTrim(char s[]);
char* rTrim(char s[]);
char* trim(char s[]);
char* nameStr(char s[]);
void readFile(char infile[], char ID[][MAX],char list[][MAX],float score[], int* n);
void writeFile(char outfile[], char ID[][MAX], char list[][MAX],float score[], int n);
void addList(char ID[][MAX],char list[][MAX],float score[],int* n);
void printList(char ID[][MAX], char list[][MAX],float score[], int n);
void sortByScore(char ID[][MAX], char list[][MAX], float score[], int n);
int main(int argc, char *argv[]){
	int n=0, choice;
	char list[MAX][MAX];
	char ID[MAX][MAX];
    float score[MAX];
    
    char infile[]="students1.txt";
	char outfile[]="students2.txt";
	readFile(infile,ID,list,score,&n);
    printList(ID,list,score,n);
	do{
		fflush(stdin);
		MENU();
		printf("\nYour choice: ");
		scanf("%d", &choice);
		switch(choice){
			case 1: 
					if(checkFull(n)) printf("\nThe array is full.\n");
					else{
					addList(ID,list,score, &n);					
					printf("\nAdded!\n");
					writeFile(outfile,ID,list,score,n);}
			       break;
		case 2:
				    if(checkEmpty(n)) printf("\nThe array is empty.\n");
			    	else
			    	    printf("list: \n");
				        printList(ID,list,score,n);   
				   break;
		
			case 3:
				    if(checkEmpty(n)) printf("\nThe array is empty.\n");
			        else 
			             printf("After sort: ");
					     sortByScore(ID,list, score, n);
			         break;
			    	         
	}
	}while(choice != 0);
	 printf("Goodbye!");
	return 0;
}
void MENU(){
        printf("\n==========================MENU==========================\n");
		printf("\n1- Add a student into the list");                     
	    printf("\n2- Print out the all list");                            
		printf("\n3- Sort the student list in ascending order by score");
		printf("\n0- Exit");
	}
int checkFull(int n)
{
	return n == MAX;
}

int checkEmpty(int n)
{
	return n == 0;
}

char* lTrim (char s[])
{
	int i = 0;
	while (s[i] == ' ')	i++;
	if (i > 0) strcpy(&s[0], &s[i]);
	return s;
}

char* rTrim (char s[])
{
	int i = strlen(s) - 1;
	while (s[i] == ' ') i--;
	s[i+1] = '\0';
	return s;
}

char* trim (char s[])
{
	rTrim(lTrim(s));
	char *ptr = strstr(s, "  ");
	while (ptr != NULL)
	{
		strcpy(ptr, ptr + 1);
		ptr = strstr(s, "  ");
	}
	return s;
}

char* nameStr(char s[]){
	trim(s);
	strlwr(s);
	int L = strlen(s);
	int i;
	for(i = 0; i < L; i++)
	   if(i == 0 || (i > 0 && s[i-1] == ' ')) 
	     s[i] = toupper(s[i]);
}
//read students1.txt
void readFile(char infile[], char ID[][MAX],char list[][MAX],float score[], int* n){
	FILE* pf = fopen(infile, "r");
	if(pf!=NULL){
		while(fscanf(pf,"%[^;];%[^;];%f%*c",ID[*n],list[*n],&score[*n])==3){
			(*n)++;
		}
		fclose(pf);
	}
}
//write students2.txt
void writeFile(char outfile[], char ID[][MAX], char list[][MAX],float score[], int n){
	FILE* f = fopen(outfile, "w");
	for(int i=0; i<n; i++){
		fprintf(f,"%s;%s;%g\n",ID[i],list[i],score[i]);
	}
	fclose(f);
}

//add
void addList(char ID[][MAX],char list[][MAX],float score[],int* n){
	printf("Enter ID: ");
	fflush(stdin);
	gets(ID[*n]);
	
	printf("Enter name: ");
	fflush(stdin);
	gets(list[*n]);
	nameStr(list[*n]);

	printf("Enter score: ");
	scanf("%f", &score[*n]);
	(*n)++;
}                     
void printList(char ID[][MAX], char list[][MAX],float score[], int n){
	for(int i=0;i<n;i++){
		printf("\n%15s",ID[i]);
		printf("%15s",list[i]);
		printf("%15.2f",score[i]);
	}
}
void sortByScore(char ID[][MAX], char list[][MAX], float score[], int n){
	char ID2[MAX][MAX];
    char list2[MAX][MAX];
    float score2[MAX];
    char x[MAX];
    float num;
    int i,j;
    for(i=0;i<n;i++){
    	strcpy(ID2[i],ID[i]);
     	strcpy(list2[i],list[i]);
     	score2[i]=score[i];
      }
     for(i=0;i<n-1;i++){
      for(j=n-1;j>i;j--){
 	   	if(score2[j]<score2[j-1]){
 	   		
 	   		strcpy(x,ID2[j]);
 			strcpy(ID2[j],ID2[j-1]);
 			strcpy(ID2[j-1],x);
 			
 			strcpy(x,list2[j]);
 			strcpy(list2[j],list2[j-1]);
 			strcpy(list2[j-1],x);
 			
 			num=score2[j];
 			score2[j]=score2[j-1];
 			score2[j-1]=num;
		 }
	 }
 }
     printList(ID2,list2,score2,n);
}
