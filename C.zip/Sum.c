#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int x,s=0;
	scanf("%d",&x);
	while(x!=0){
		s += x;
		scanf("%d", &x);
	}
	printf("Sum = %d",s);
	
	return 0;
}
