#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int n;
	while(1){
		
		printf("Enter value of n: ");
		scanf("%d",&n);
		
		if( n<0 ){
			do{
				printf("Enter value of n: ");
				scanf("%d",&n);
			}while(n<0);
		}
		
		if( n==0 ){
			printf("Goodbye!");
			break;
		}else{
			print(n);
		}
	}
	return 0;
}

int print( int n ){
	
	int i;
	int count=0;
	double x,y,z;
	
	x=0;
	y=1;
	z=1;
	
	for(i=1;i<=n;i++){
		printf("%1.lf ",z);
		count=count+1;
		
		z=x+y;
		x=y;
		y=z;
		
		if (count%5==0){
			printf("\n");
		}
	}
	printf("\n");
}
