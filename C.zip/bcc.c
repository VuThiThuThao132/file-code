#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a,b;
	printf("Enter the low of the range: ");
	scanf("%d",&a);
	printf("Enter the low of the range: ");
	scanf("%d",&b);
	int i,j;
	for (i=a;i<=a;i++){
    	printf ("%6d",i);}
    for(i=a+1;i<=b;i++){
    	printf ("%5d",i);
		}
    printf("\n");
	bcc(a,b);	}
 int  bcc( int a, int b) {
    int i,j;     
  {    for(i=a;i<=b;i++){
      	printf("%d",i);
      	for(j=a;j<=b;j++){
      		printf("%5d",i*j);}
      	printf("\n");	
	  }
  
}
  return 0;
    	
}
