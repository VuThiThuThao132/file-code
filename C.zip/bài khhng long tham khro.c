#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include<windows.h>
#include <string.h>

#define MID 105

void startGame(int total);
void title(int total,int count);
int Dice(int n,int space,int layout);
int DiceA(int nA,int total,int count,int key);
void DiceAB(int nA,int nB,int spA,int total,int count,int key);
void delay(int number_of_seconds);
void fullscreen(); 
void hidecursor();
void gotoxy(int x, int y);
void textColor(int color);
int chosseOption(int x,int y,int count);
int YesNo();
void KhungLongcute(char mess[],int position);



//=================================Main=================================
int main(){
	fullscreen();
	srand(time(NULL));
	hidecursor();
	int n,chu;
	char c;
	bool check;
	do{
		chu=0;
		do{
			system("cls");
			printf("@Copyright by Minh Chu");
			if(chu==1){
				KhungLongcute("[!] RE-ENTER A VALUE BETWEEN [2...12] [!]",68);
			}else KhungLongcute("MY NAME IS CHU",68);
			fflush(stdin);
			gotoxy(MID-15,21);printf("ENTER TOTAL SOUGHT : ");
			check=scanf("%d%c",&n,&c); 
			fflush(stdin);
			chu=1;
		}while(check==false||n<2||n>12||c!=10);
		startGame(n);
		
	}while(YesNo()==1);
	
}
//=================================Function=================================
void startGame(int total){
	int a,b,count=0,spA;
	while("Chu"=="Chu"){
		system("cls");	
		count++;
		a=rand()%6+1;
		b=rand()%6+1;
		title(total,count);
		delay(500);
		spA=DiceA(a,total,count,1);DiceAB(a,b,spA,total,count,1);
		if(a+b==total){	
			textColor(11);  				  	
			gotoxy(MID-(36/2),30);printf("__YOU GOT YOUR TOTAL IN %d THROWS__",count);	
			textColor(15);
			delay(2000);
			system("cls");
			title(total,count);
			delay(1000);
			return;
		}
		delay(1200);
	}
	
}
void title(int total,int count){
	int i;
	printf("@Copyright by Minh Chu");
	textColor(14);       
	gotoxy(MID-(94/2),4);printf(" /$$       /$$   /$$  /$$$$$$  /$$   /$$ /$$      /$$    /$$$$$$$  /$$$$$$  /$$$$$$  /$$$$$$$$");
	gotoxy(MID-(94/2),5);printf("| $$      | $$  | $$ /$$__  $$| $$  /$$/ | $$    /$$/   | $$__  $$|_  $$_/ /$$__  $$| $$_____/");
	gotoxy(MID-(94/2),6);printf("| $$      | $$  | $$| $$  |__/| $$ /$$/  \\  $$  /$$/    | $$  | $$  | $$  | $$  |__|| $$      ");
	gotoxy(MID-(94/2),7);printf("| $$      | $$  | $$| $$      | $$$$$/    \\  $$/$$/     | $$  | $$  | $$  | $$      | $$$$$   ");
	gotoxy(MID-(94/2),8);printf("| $$      | $$  | $$| $$      | $$  $$     \\  $$$/      | $$  | $$  | $$  | $$      | $$__/   ");
	gotoxy(MID-(94/2),9);printf("| $$      | $$  | $$| $$    $$| $$\\  $$     | $$/       | $$  | $$  | $$  | $$    $$| $$      ");
	gotoxy(MID-(94/2),10);printf("| $$$$$$$$|  $$$$$$/|  $$$$$$/| $$ \\  $$    | $$        | $$$$$$$/ /$$$$$$|  $$$$$$/| $$$$$$$$");
	gotoxy(MID-(94/2),11);printf("|________/ \\______/  \\______/ |__/  \\__/    |__/        |_______/ |______/ \\______/ |________/");	
	textColor(11);  						  
	gotoxy(MID-(18/2),13);printf("TOTAL SOUGHT : %d ",total);
	gotoxy(MID-(26/2),14);printf("NUMBER OF DICE TOSSES : %d",count);
	textColor(1);
	gotoxy(MID-(132/2),16);printf("====================================================================================================================================\n\n");
	for(i=17;i<=31;i++){
		gotoxy(MID-(132/2),i);printf("||");gotoxy(MID+(132/2)-2,i);printf("||");
	}
	gotoxy(MID-(132/2),32);printf("====================================================================================================================================\n");
	textColor(15);
}
int Dice(int n,int space,int layout){
	switch(n){
		case 1:{
			                             
			gotoxy(MID+(10)-space,17+layout);printf(" ,,,,,,, ");
			gotoxy(MID+(10)-space,18+layout);printf("|       |");
			gotoxy(MID+(10)-space,19+layout);printf("|");textColor(12);printf("   *   ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,20+layout);printf("|       |");
			gotoxy(MID+(10)-space,21+layout);printf(" '''''''");
			break;
		}
		case 2:{
			gotoxy(MID+(10)-space,17+layout);printf(" ,,,,,,,");
			gotoxy(MID+(10)-space,18+layout);printf("|");textColor(12);printf(" *     ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,19+layout);printf("|       |");
			gotoxy(MID+(10)-space,20+layout);printf("|");textColor(12);printf("     * ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,21+layout);printf(" '''''''");
			break;
		}
		case 3:{
			gotoxy(MID+(10)-space,17+layout);printf(" ,,,,,,,");
			gotoxy(MID+(10)-space,18+layout);printf("|");textColor(12);printf(" *     ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,19+layout);printf("|");textColor(12);printf("   *   ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,20+layout);printf("|");textColor(12);printf("     * ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,21+layout);;printf(" '''''''");
			break;
		}
		case 4:{
			gotoxy(MID+(10)-space,17+layout);printf(" ,,,,,,,");
			gotoxy(MID+(10)-space,18+layout);printf("|");textColor(12);printf(" *   * ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,19+layout);printf("|       |");
			gotoxy(MID+(10)-space,20+layout);printf("|");textColor(12);printf(" *   * ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,21+layout);printf(" '''''''");
			break;
		}
		case 5:{
			gotoxy(MID+(10)-space,17+layout);printf(" ,,,,,,,");
			gotoxy(MID+(10)-space,18+layout);printf("|");textColor(12);printf(" *   * ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,19+layout);printf("|");textColor(12);printf("   *   ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,20+layout);printf("|");textColor(12);printf(" *   * ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,21+layout);printf(" '''''''");
			break;
		}
		case 6:{
			gotoxy(MID+(10)-space,17+layout);printf(" ,,,,,,,");
			gotoxy(MID+(10)-space,18+layout);printf("|");textColor(12);printf(" *   * ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,19+layout);printf("|");textColor(12);printf(" *   * ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,20+layout);printf("|");textColor(12);printf(" *   * ");textColor(15);printf("|");
			gotoxy(MID+(10)-space,21+layout);printf(" '''''''");
			break;
		}
	}
	return space;
}			      
int DiceA(int nA,int total,int count,int key){
	int i,sp,round,space,n;
	if(key==1){		
		round = rand()%8+3; 
		for(i=0;i<=round;i++){
			system("cls");
			title(total,count);
			space=rand()%21;	
			n=i==round?nA:rand()%6+1;		
			sp=Dice(n,space,1);
			delay(100);
		}	
	}
	return sp;	
} 
void DiceAB(int nA,int nB,int spA,int total,int count,int key){
	delay(700);
	int i,round,sp,space,n;
	if(key==1){
		round = rand()%8+3;
		for(i=0;i<=round;i++){
			system("cls");
			title(total,count);
			Dice(nA,spA,1);  
			space=rand()%21;
			n=i==round?nB:rand()%6+1;
			sp=Dice(n,space,7);
			delay(100);
		}	
	}
}
void delay(int time){ 
    clock_t startTime = clock(); 
    while (clock() < startTime + time); 
}
void fullscreen(){
	keybd_event(VK_MENU,0x38,0,0);
	keybd_event(VK_RETURN,0x1c,0,0);
	keybd_event(VK_RETURN,0x1c,KEYEVENTF_KEYUP,0);
	keybd_event(VK_MENU,0x38,KEYEVENTF_KEYUP,0);
}
void hidecursor(){
	HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO ConCurInf;
	ConCurInf.dwSize = 10;
	ConCurInf.bVisible = FALSE;
	SetConsoleCursorInfo(hOut, &ConCurInf);
}
void gotoxy(int x, int y){
	COORD point;
    point.X = x; point.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),point);
}
int YesNo(){
	int cond=2;
	char opption =' ';
	do{	
		fflush(stdin);
		textColor(9);			     	
		gotoxy(MID-(26/2),20);printf(".------------------------.");
		gotoxy(MID-(26/2),21);printf("|                        |");
		gotoxy(MID-(26/2),22);printf("|  DO YOU WANT REPLAY ?  |");
		gotoxy(MID-(26/2),23);printf("|                        |");
		gotoxy(MID-(26/2),24);printf("|         [ YES ]        |");
		gotoxy(MID-(26/2),25);printf("|         [ NO! ]        |");
		gotoxy(MID-(26/2),26);printf("|                        |");
		gotoxy(MID-(26/2),27);printf("'------------------------'");
		textColor(15);
		cond=chosseOption(MID-6,24,2);
	}while(!(cond==1||cond==2));
	gotoxy(0,40);
	if(cond==2){
		return 0;
	}else if(cond==1) return 1;
}
int chosseOption(int x,int y,int count){
	int DOWN=80,UP=72;
	int input,d,i=y;
	while((d=getch())!=13){
		if(d==224)input=getch();
			else continue;
		gotoxy(x,i);printf(" ");
		gotoxy(x+12,i);printf(" ");
		i=input==UP?i-1:(input==DOWN?i+1:0);
		i=i<y?y+count-1:(i>count+y-1?y:i);
		textColor(9);	
		gotoxy(x,i);printf(">");
		gotoxy(x+12,i);printf("<");
		textColor(15);
		gotoxy(MID-(26/2),35);printf("%d",i-y+1);
	}
	
	return i-y+1;
}
void textColor(int color){
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}
void KhungLongcute(char mess[],int position){
	int i,length=strlen(mess);
	gotoxy(position,1);printf(" ");for(i=0;i<length+4;i++)printf("=");
	gotoxy(position,2);printf("||",mess);gotoxy(length+position+4,2);printf("||");
	gotoxy(position,3);printf("|| %s ",mess);gotoxy(length+position+4,3);printf("||");
	gotoxy(position,4);printf("||",mess);gotoxy(length+position+4,4);printf("||");
	gotoxy(position,5);printf(" ");for(i=0;i<length+4;i++)printf("=");
	gotoxy(position,6);printf("\\");textColor(10);printf("                             .       .");textColor(15);
	gotoxy(position,7);printf(" \\");textColor(10);printf("                           / `.   .' \"");textColor(15);
	gotoxy(position,8);printf("  \\");textColor(10);printf("                  .---.  <    > <    >  .---.");textColor(15);
	gotoxy(position,9);printf("   \\");textColor(10);printf("                 |    \\  \\ - ~ ~ - /  /    |");textColor(4);
	gotoxy(position,10);printf("         _____");textColor(10);printf("          ..-~             ~-..-~");textColor(4);
	gotoxy(position,11);printf("        |     |");textColor(10);printf("   \\~~~\\.'                    `./~~~/");;textColor(4);
	gotoxy(position,12);printf("       ---------");textColor(10);printf("   \\__/                        \\__/");
	gotoxy(position,13);printf("      .'  O    \\     /               /       \\  \"");
	gotoxy(position,14);printf("     (_____,    `._.'               |         }  \\/~~~/");
	gotoxy(position,15);printf("      `----.          /       }     |        /    \\__/");
	gotoxy(position,16);printf("            `-.      |       /      |       /      `. ,~~|");
	gotoxy(position,17);printf("                ~-.__|      /_ - ~ ^|      /- _      `..-'");
	gotoxy(position,18);printf("                     |     /        |     /     ~-.     `-. _  _  _");
	gotoxy(position,19);printf("                     |_____|        |_____|         ~ - . _ _ _ _ _ >");textColor(15);
}
