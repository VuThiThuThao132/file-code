#include <stdio.h>
 
/*
    Gi? s? v?i s? n = 1234
    n = 1 * 1000 + 2 * 100 + 2 * 10 + 4 * 1
            10^3        10^2    10^1       10^0
    �?o ngu?c th? n�o?
    B1: num = 4
    B2: num = 4 * 10 + 3 = 43
    B3. num = 43 * 10 + 2 = 432
    B4. num = 432 * 10 + 1 = 4321
 */
 
int Reverse(int n){
    /*
        L?y ch? s? cu?i c�ng b?ng c�ch chia du cho 10
        B? ch? s? cu?i c�ng b?ng c�ch chia cho 10
     */
    int reNum = n % 10; // B1: L?y ch? s? cu?i c�ng
    n /= 10; // B? ch? s? cu?i c�ng
    int last;
    while(n > 0){
        last = n % 10; // L?y ch? s? cu?i c�ng
        n /= 10; // B? ch? s? cu?i c�ng
        reNum = reNum * 10 + last; // Ch�nh l� c�c bu?c 2 3 4
    }
    return reNum;
}
 
int main(){
    int num;
    printf("Nhap num = ");
    scanf("%d", &num);
    printf("\nReNum = %d", Reverse(num));
}
