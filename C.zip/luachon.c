#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char luachon;
	printf("Cau hoi: Con cho di bang may chan:\n ");
	printf("A. 1\nB. 2\nC. 3\nD. 4\n");
	printf("Dap an ban chon la (a,b,c,d): ");
	luachon= getchar();
	
	switch (luachon){
		case 'A':
		case 'a':
		case 'B':
		case 'b':
		case 'C':
		case 'c':
                {printf ("\nRat tiec, ban da chon sai!");
                  break;
				}
		case 'D':
       	case 'd':
                {printf ("\nChuc mung, ban da chon dung!");
                  break;
			    }
        default:
        	    {printf("\nDap an ban nhap khong hop le!");
	            }
   }
	return 0;
}
