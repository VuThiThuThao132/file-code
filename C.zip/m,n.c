#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    int n=7, m=8;
    int* p1= &n, *p2=&m;
    *p1 +=5 + 3*(*p2) -n;
    *p2 = 5*(*p1)�4*m + 2*n;
    printf("m= %d");
    printf("n= %d");
   	return 0;
}
