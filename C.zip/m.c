#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
       int n=7,m=8;
       int* p1= &n, *p2=&m;
       *p1 +=12-m+ (*p2);
       *p2 = m + n- 2*(*p1);

       printf("%c+%c=%d", m+n); 
	return 0;
}
