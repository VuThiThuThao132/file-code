#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int N;
    do{
    printf("Enter number of kwhs:");
    scanf ("%d",& N);
	    if (N<0) printf("Enter number integer \n");
       }
    while (N<0);
	   	if (N<100) printf("prices: %d",N*950); 
	    if (N<=150) {
		 printf("prices: %d ",100*950+(N-100)*1250);
		 }
            else{
             if (N<=200){ 
			 printf("prices: %d ",100*950+50*1250+(N-150)*1350);
			 }
			 else {
			 printf("prices: %d ",100*950+50*1250+(N-150)*1350+(N-200)*1550);
			 }
        }  
     return 0;
}

