#include <stdio.h>
#include <stdlib.h>
#define ENTER 10
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char c;
	int noDigits=0,noLetters=0,noOthers= 0,i=1;
	printf("Enter a string:  ");
	while (c!=ENTER)
        {
	    scanf("%c",&c) ;
        if ( c>=48 && c <=57) 
	    {
	        noDigits++;}
	    else
	        {
	        if ( (c>='a' && c <='z') || (c>='A' && c <='Z') ){
			
		         	noLetters++;
			}
           
	        else {
			       noOthers++;
            } 
        }
    
        
    } 
     printf("digits: %d\nletters: %d\nothers: %d",noDigits, noLetters, noOthers-i);
	return 0;
}
