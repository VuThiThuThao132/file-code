include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char code1,code2, code,t;
    printf ("Enter the first character: \n ");
    scanf("%c",&code1);
	 getchar();

	printf ("Enter the second character:\n");
	scanf("%c",&code2);
	 getchar();
	
	if (code1>code2)
	{ t=code1;code1=code2;code2=t;}
    printf("\ncharacter\tDec\tOctal\tHEX\n ------\t-----\t-----\t-----\n");
    for(code=code1; code<=code2; code++){
    	printf("%c,%d, %o, %X\n", code, code,code,code);
    	}
    
     return 0;
}
