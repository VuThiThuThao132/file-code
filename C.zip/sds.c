#include<stdio.h>

#include<string.h>

#include<time.h>

#include<stdlib.h>

typedef struct {

                int ngay,thang,nam;

} date;

typedef struct {

                char masv[6],hoten[31],diachi[51],gioitinh[4];

                float diemtb;

                date ngaysinh;

} hocsinh;

int main() {
                srand(time(NULL));

                hocsinh shs[30];

                int n,i,j,tam,t;

                n = 20 + rand()%10;

                for(i=0; i<n; i++) {

                                for(j=0; j<5; j++) {

                                                tam = 48 + rand()%42;

                                                if((tam<=90 && tam>=65) || (tam<=57 && tam>=48)) {

                                                                shs[i].masv[j] = (char)tam;

                                                                tam=0;

                                                } else

                                                                i--;

                                                shs[i].masv[5] = '\0';

                                }

                }

                for(i=0; i<n; i++) {

                                for(j=0; j<29; j++) {

                                                tam = 97 + rand()%25;

                                                if((tam<=122 && tam>=97)) {

                                                                shs[i].hoten[j] = (char)tam;

                                                                tam=0;

                                                } else

                                                                i--;

                                                shs[i].hoten[28] = '\0';

                                }

                }

                for(i=0; i<n; i++) {

                                if(shs[i].hoten[0] == ' ') {

                                                for(j=0; j<strlen(shs[i].hoten); j++) {

                                                                if(shs[i].hoten[j] ==' ' && shs[i].hoten[j] !=' ')

                                                                                shs[i].hoten[j+1] = shs[i].hoten[j+1] - 32;

                                                }

                                } else {

                                                shs[i].hoten[0] = shs[i].hoten[0] - 32;

                                                for(j=0; j<strlen(shs[i].hoten); j++) {

                                                                if(shs[i].hoten[j] ==' ' && shs[i].hoten[j] !=' ')

                                                                                shs[i].hoten[j+1] = shs[i].hoten[j+1] - 32;

                                                }

                                }

                }

                for(i=0; i<n; i++) {

                                shs[i].ngaysinh.ngay = rand()%29;

                                shs[i].ngaysinh.thang = 1 + rand()%11;

                                shs[i].ngaysinh.nam = 1993 + rand()%20;

                }

                for(int i=0; i<n; i++) {

                                for(int j=0;; j++) {

                                                tam = rand()%2;

                                                if(tam == 0) {

                                                                shs[i].gioitinh[0] = 'N';

                                                                shs[i].gioitinh[1] = 'u';

                                                                shs[i].gioitinh[2] = '\0';

                                                                tam=2;

                                                                break;

                                                } else if(tam == 1) {

                                                                shs[i].gioitinh[0] = 'N';

                                                                shs[i].gioitinh[1] = 'a';

                                                                tam=2;

                                                                shs[i].gioitinh[2] = 'm';

                                                                shs[i].gioitinh[3] = '\0';

                                                                break;

                                                }

                                }

                }

                for(int i=0; i<n; i++) {

                                for(int j=0;; j++) {

                                                t = rand()%5;

                                                if(t == 0) {

                                                                shs[i].diachi[0] = 'H';

                                                                shs[i].diachi[1] = 'a';

                                                                shs[i].diachi[2] = ' ';

                                                                shs[i].diachi[3] = 'G';

                                                                shs[i].diachi[4] = 'i';

                                                                shs[i].diachi[5] = 'a';

                                                                shs[i].diachi[6] = 'n';

                                                                shs[i].diachi[7] = 'g';

                                                                shs[i].diachi[8] = '\0';

                                                                t=5;

                                                                break;

                                                } else if(t == 1) {

                                                                shs[i].diachi[0] = 'B';

                                                                shs[i].diachi[1] = 'a';

                                                                shs[i].diachi[2] = 'c';

                                                                shs[i].diachi[3] = ' ';

                                                                shs[i].diachi[4] = 'C';

                                                                shs[i].diachi[5] = 'a';

                                                                shs[i].diachi[6] = 'n';

                                                                shs[i].diachi[7] = '\0';

                                                                break;

                                                } else     if(t == 2) {

                                                                shs[i].diachi[0] = 'T';

                                                                shs[i].diachi[1] = 'h';

                                                                shs[i].diachi[2] = 'a';

                                                                shs[i].diachi[3] = 'i';

                                                                shs[i].diachi[4] = ' ';

                                                                shs[i].diachi[5] = 'N';

                                                                shs[i].diachi[6] = 'g';

                                                                shs[i].diachi[7] = 'u';

                                                                shs[i].diachi[8] = 'y';

                                                                shs[i].diachi[9] = 'e';

                                                                shs[i].diachi[10] = 'n';

                                                                shs[i].diachi[11] = '\0';

                                                                t=5;

                                                                break;

                                                } else if(t == 3) {

                                                                shs[i].diachi[0] = 'H';

                                                                shs[i].diachi[1] = 'a';

                                                                shs[i].diachi[2] = ' ';

                                                                shs[i].diachi[3] = 'N';

                                                                shs[i].diachi[4] = 'o';

                                                                shs[i].diachi[5] = 'i';

                                                                shs[i].diachi[6] = '\0';

                                                                t=5;

                                                                break;

                                                }

                                }

                }

                for(int i=0; i<n; i++) {

                                for(int j=0;; j++) {

                                                tam = 1 + rand()%10;

                                                shs[i].diemtb = tam;

                                                break;

                                }

                }

                for(int k = 0; k<n; k++) {

                                printf("======================\n");

                                printf("Ma sinh vien thu %d la: ",k+1);

                                puts(shs[k].masv);

                                printf("Ho ten sinh vien thu %d la: ",k+1);

                                puts(shs[k].hoten);

                                printf("Ngay thang nam sinh cua sinh vien thu %d: %d - %d - %d\n",k+1,shs[k].ngaysinh.ngay,shs[k].ngaysinh.thang,shs[k].ngaysinh.nam);

                                printf("Gioi tinh sinh vien thu %d: %s\n",k+1,shs[k].gioitinh);

                                printf("Que cua sinh vien thu %d: %s\n",k+1,shs[k].diachi);

                                printf("Dem trung binh cua sinh vien thu %d: %2.1f",k+1,shs[k].diemtb);

                                printf("\n");

                }

                printf("\n================\nCac sinh vien duoc len lop (cos dien tb>=5):\n================\n\n");

                for(int k = 0; k<n; k++) {

                                if(shs[k].diemtb>=5.0) {

                                                printf("======================\n");

                                                printf("Ma sinh vien thu %d la: ",k+1);

                                                puts(shs[k].masv);

                                                printf("Ho ten sinh vien thu %d la: ",k+1);

                                                puts(shs[k].hoten);

                                                printf("Ngay thang nam sinh cua sinh vien thu %d: %d - %d - %d\n",k+1,shs[k].ngaysinh.ngay,shs[k].ngaysinh.thang,shs[k].ngaysinh.nam);

                                                printf("Gioi tinh sinh vien thu %d: %s\n",k+1,shs[k].gioitinh);

                                                printf("Que cua sinh vien thu %d: %s\n",k+1,shs[k].diachi);

                                                printf("Dem trung binh cua sinh vien thu %d: %2.1f",k+1,shs[k].diemtb);

                                                printf("\n");

                                }

                }

                return 0;

}
