#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	printf ("Kich thuoc cuar kieu char: %d", sizeof(char));
	printf ("\nKich thuoc cuar kieu int: %d", sizeof(int));
	printf ("\nKich thuoc cuar kieu double: %d", sizeof(double));
	printf ("\nKich thuoc cuar kieu long double: %d", sizeof(long double));
	printf ("\nKich thuoc cuar kieu long long : %d", sizeof(long long));
	return 0;
	
}
