#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int isPrime (int n){
	int i;
   
	for( i= 2; i<n; i++)
	    if(n%i==0) return 0;
	    	return 1;}
int main(int argc, char *argv[]) {
	int t,n;
	printf("Enter the number: ");
	scanf("%d",&n);
	if (isPrime(n))
	printf("% is prime.",n);
	 else
	 printf("%d isn't prime.",n);	
	return 0;
}
