#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define MAX 100
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
typedef struct student{
	char name[MAX];
	char MSSV[10];
//	char address[51];
	double score;
}student;
void MENU();
void clear();
int getInt(int min , int max);
void readFile(char filename[],struct student S[],int* n);
void writeFile(char filename, struct student S[], int n);
char* lTrim (char s[]);
char* rTrim (char s[]);
char* trim (char s[]);
char* nameStr(char s[]);
void add(student S[], int* n);
void printArray(student S[], int n);
void search(student S[], int n);
void remove( student S[], int* n);
void swapStudent(student* s1, student* s2);
void sortByName(student S[], int n);
void sortByScoreAscen(student S[], int n);
void sortByScoreDescen(student S[], int n);
int main(int argc, char *argv[]) {
	int n = 0, choice;
	struct student S[MAX];
	char infile[]="students1.txt";
	char outfile[]="students2.txt";
	readFile( S, &n);
    print(S,n);
	do{
		MENU();
		printf("\nYour choice: ");
		scanf("%d", &choice);
		switch(choice){
			case 1: 
			       add(S, &n);
			       break;
			case 2: 
			       printArray(S, n);
			       break;
			case 3: 
			       printArray(S, n);
			       remove(S, &n);
			       break;
			case 4: 
			       search(S, n);
			       break;
			case 5: 
			       printf("\nAfter sorting: \n");
                   SortByName(S, n);
			       break;
			case 6: 
			       printf("\nAfter sorting: \n");
			       sortByScoreAscen(S, n);
			       break;
		    case 7: 
			       printf("\nAfter sorting: \n");
			       sortByScoreDescen(S, n);
			       break;
		}
	}while(choice != 0);
	printf("Goodbye!");
	return 0;
}
void MENU(){
	printf("\n=====MENU=====\n");
	printf("1- Add a student\n");
	printf("2- Print out list\n");
	printf("3- Remove student\n");
	printf("4- Search student\n");
	printf("5- Sort the list by name");
	printf("6- Sort the list by score in ascending order\n");
	printf("7- Sort the list by score in descending order\n");
}
void readFile(char filename[],struct student S[],int* n){
	FILE* pf= fopen(filename, "r");
	if (pf != NULL)
	{
		while (fscanf(pf,"%[^;];%[^;];%[^;];%d%c",S[*n].ID,S[*n].name,&S[*n].score) == 3){
			(*n)++;
		}
		fclose(pf);
	}
}
void writeFile(char filename, struct student S[], int n){
	FILE* f = fopen(filename, "w");
	for(int i = 0; i < n; i++){
		fprintf(f,"%s;%s;%s;%d",S[i].ID,S[i].name,S[i].score);
		fprintf(f,"\n");
	}
	fclose(f);
}
char* lTrim (char s[]){
	int i = 0;
	while (s[i] == ' ')	i++;
	if (i > 0) strcpy(&s[0], &s[i]);
	return s;
}

char* rTrim (char s[]){
	int i = strlen(s) - 1;
	while (s[i] == ' ') i--;
	s[i+1] = '\0';
	return s;
}

char* trim (char s[]){
	rTrim(lTrim(s));
	char *ptr = strstr(s, "  ");
	while (ptr != NULL)
	{
		strcpy(ptr, ptr + 1);
		ptr = strstr(s, "  ");
	}
	return s;
}

char* nameStr(char s[]){
	trim(s);
	strlwr(s);
	int L = strlen(s);
	int i;
	for(i = 0; i < L; i++)
	   if(i == 0 || (i > 0 && s[i-1] == ' ')) 
	     s[i] = toupper(s[i]);
}
void add(student S[], int* n){
	printf("Enter ID: ")
	fflush(stdin);
	gets(S[*n]);
	
	printf("Enter name:");
	fflush(stdin);
	gets(S[*n].name);
	nameStr(S[*n].name);
	
	printf("Enter score: ");
	S[*n].score = getNumber(1,10);
	(*n)++;
}
void printArray(student S[], int n){
	int i;
	for(i = 0; i < n ; i++){
		printf("%15%15s%10.1lf\n",S[i].ID,S[i].name, S[i].score);
	}
}
void search(student S[], int n){
	int i, flag = 0;
	char x[MAX];
	printf("Enter name to search: ");
	fflush(stdin);
	gets(x);
	nameStr(x);
	for(i = 0; i < n; i++){
		char* ptr = strstr(S[i].name, x);
		if(ptr != NULL){
			printf("%15s%15s%10.1lf\n", S[i].ID,S[i].name, S[i].score);
			flag = 1;
		}
}
    if (flag == 0)
        printf("Name not exit!\n");
}
void remove(student S[], int* n){
	int flag = 0;
	char x[MAX];
	printf("Enter name to remove: ");
	fflush(stdin);
	gets(x);
	nameStr(x);
	for(int i = 0; i < *n; i++){
		if(strcmp(S[i].name, x) == 0){
			for(int j = i; j < *n; j++)
			   S[j] = S[j - 1];
			(*n)--;
			i--;
			flag = 1;
	}
}
    if(flag == 1){
    	printf("After remove: \n");
    	printArray(S, *n);
	}else
	    printf("Name not exit.\n");
}
void swapStudent(student* s1, student* s2){
	student t;
	t = *s1;
	*s1 = *s2;
	*s2 = t;
}
void sortByName(student S[], int n){
	int i,j;
	student S2[MAX];
	for(int i = 0; i < n; i++){
		for(int j = n - 1; j > i; j--)
		   if(strcmp(S2[j].ID,S2[j - 1].name, S2[j].name) > 0){
		   	swapStudent(&S2[j],&S2[j - 1], &S2[j]);
		   }
	}
	printArray(S2, n);
}
void sortByScoreAscen(student S[], int n){
	student S2[MAX];
	for(int i = 0; i < n; i++)
	     S2[i] = S[i];
	   for(int j = n-1; j > i; j--){
	   	  if(S2[j - 1].score > S2[j].score){
	   	  	swapStudent(&S2[j - 1], &S2[j]);
			 }
	   }
	   printArray(S2,n);
}
void sortByScoreDescen(student S[], int n){
	student S2[MAX];
	for(int i = 0; i < n; i++)
	    S2[i] = S[i];
	   for(int j = n-1; j > i; j--){
	   	  if(S2[j - 1].score < S2[j].score){
	   	  	swapStudent(&S2[j - 1], &S2[j]);
			 }
	   }
	   printArray(S2,n);
}


