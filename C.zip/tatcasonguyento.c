#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int isPrime(int n){
	if (n<2){return 0;
	}
	int i;
	for ( i=2; i<n; i++){
	     if (n%i==0)  {return 0; 
	 	}    	
    } 
    return 1;
}    
int main(int argc, char *argv[]) {
	int i,n;
		printf("nhap so n= ");
		scanf("%d",&n);
		printf("tat ca cac so nguyen to nho hon %d la: \n",n);
	
	    for(i=0;i<=n;i++){
				if (isPrime(i)==1){
					printf("%5d",i);
             }
	   }
	   return 0;
	   
    }    
	

        

