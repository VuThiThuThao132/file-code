#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int n, i;
    long s;
    s=0;
    i=1;
    printf("\nNhap n: ");
    scanf("%d", &n);
    while (i<=n){
    	s= s + i;
    	i++;
    }
    printf("\nTong 1+2+....+%d la %d",n,s);
    getch();
	return 0;
}
