#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a,b,S;
	printf("Nhap vao so nguyen thu nhat: ",a);
	scanf("%d",&a);
	printf("\nNhap vao so nguyen thu hai: ",b);
	scanf("%d",&b);
	S = a*a + b*b;
	printf("\nTong binh phuong 2 so nguyen la: %d^2 + %d^2 = %d ",a,b,S);
	return 0;
}
