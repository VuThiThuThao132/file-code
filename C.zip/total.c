#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int quantity;
	double cost, total, tax;
	printf ("Enter the number of apples desired: ");
	scanf ("%d", &quantity);
	printf ("Now enter the cost of one apple (in $): ");
	scanf("%lf", &cost);
	total= quantity * cost;
	if (total > 100)
	    total = 100 + (total -100)*0.9;
	    tax = 0.15 * total;
	printf ("That will cost ($%.2lf plus $%.2lf tax): $%.2lf\n",total,tax, total +tax);

	
	return 0;
}
