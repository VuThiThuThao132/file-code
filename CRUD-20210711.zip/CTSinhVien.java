/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ctsinhvien;

/**
 *
 * @author hunagroup
 */
public class CTSinhVien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Student sA = new Student("SV001", "An", 23, 9,8,9);
        // sA --> id=SV001,name=An, age=23, math=9, english=8, informatic=9
        Student sB = new Student("SV002", "Bình", 19, 9,10,9);
        
        sA.display();
        
        sB.display();
        
        // So sánh điểm trung bình sinh viên A với B
        int result = sA.rank(sB);
        
        if(result == 1){
            System.out.println("A giỏi hơn B");
        }
        if(result == 0){
            System.out.println("A ngang B");
        }
         if(result == -1){
            System.out.println("A kém hơn B");
        }
         
        System.out.println("Kết thúc chương trình");
    }  
}
