/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ctsinhvien;

import java.util.ArrayList;

/**
 *
 * @author hunagroup
 */
public class CTSinhVien2 {
    public static void main(String[] args) {
        // 1. Tạo danh sách chứa 5 sinh viên
        // 2. Xuất danh sách các sinh viên ra màn hình
        // 3. Sắp xếp danh sách các sinh viên theo điểm trung bình
        
        // Tạo ra danh sách để lưu trữ các sinh viên
        ArrayList<Student> dsSinhVien = new ArrayList<Student>();
        // Array: Mảng --> khó thao tác
        
        // Tạo 5 sinh viên
        Student sv1 = new Student("SV001", "An", 23, 9,8,9);
        Student sv2 = new Student("SV002", "Bình", 22, 9,10,9);
        Student sv3 = new Student("SV003", "Cường", 18, 10,8,9);
        Student sv4 = new Student("SV004", "Duy", 19, 9,8,7);
        Student sv5 = new Student("SV005", "Tùng An", 20, 8,8,8);
        
        //1. Create: Đặt (thêm) các sinh viên vào danh sách dsSinhVien
        dsSinhVien.add(sv1);
        dsSinhVien.add(sv2);
        dsSinhVien.add(sv3);
        dsSinhVien.add(sv4);
        dsSinhVien.add(sv5);
        
        //2. Read: In ra màn hình các sinh viên đang có trong danh sách
        for(Student st : dsSinhVien){
            st.display();
        }
        
        //3. Detail: Xuất thông tin của một sinh viên nào đó với id cụ thể.
        // Căn cứ vào mã định danh (duy nhất) của sinh viên trong danh sách
        // ---> căn cứ vào id
        String idcanlay = "SV004";
        for(Student st:dsSinhVien){
            if(st.getId().equals(idcanlay)){ // Trong Java, so sánh chuỗi, hay đối tượng ,người dùng equals
                st.display();
            }
        }
        
        //4. Delete: Thao xóa 1 sinh viên cụ thể
        // Cần thông qua mã số định danh --> id
        String ident = "SV002";
        for(int i = 0; i < dsSinhVien.size(); i ++){
            if(dsSinhVien.get(i).getId().equals(ident)){
                dsSinhVien.remove(i);
            }
        }
        // Kiểm tra lại xem đã xóa chưa
        System.out.println("Danh sách sau khi xóa");
        for(Student st : dsSinhVien){
            st.display();
        }
        
        //5.Update: Cập nhật thông tin của sinh viên cụ thể
        // Cập nhật thông tin sinh viên: Tức là cập nhật cái gì?
        // -->Tức là cập nhật giá trị cho các Fields
        // Tuy nhiên, mã số định danh là phải cố định
        // Cố định: "SV004",có thể thay đổi: "Duy", 19, 9,8,7
        // Khai báo một biến sinh viên tạm
        Student temp = new Student("SV004","Tường", 22, 9,8,7);
        for(int i = 0; i < dsSinhVien.size(); i ++){
            if(dsSinhVien.get(i).getId().equals(temp.getId())){
                dsSinhVien.get(i).setName(temp.getName());
                dsSinhVien.get(i).setAge(temp.getAge());
                dsSinhVien.get(i).setMath(temp.getMath());
                dsSinhVien.get(i).setEnglish(temp.getEnglish());
                dsSinhVien.get(i).setInformatic(temp.getInformatic());
            }
        }
        
        System.out.println("Danh sách sau khi edit");
        for(Student st : dsSinhVien){
            st.display();
        }
        
        // --> 5 thao tác phía trên được gọi CRUD 
        // trong một chương trình quản lý ứng dụng cơ bản
        // Quản lý ứng dụng thường tập trung vào CRUD trên danh sách chứa các đối tượng
        // CRUD ?
        // C: Create - Tạo mới một đối tượng / thêm một đối tượng vào danh sách
        // R: Read -> Hiển thị/lấy thông tin của đối tượng trong danh sách
        //          (1) Lấy danh sách của tất cả các đối tượng
        //          (2) Lấy thông tin của 1 đối tượng cụ thể (id)
        // U: Update --> Cập nhật thông tin của một đối tượng cụ thể trong danh sách
        // D: Delete --> Xóa thông tin của một tượng cụ thể trong danh sách, thông qua (id)
        // Do đó, để xây dựng ứng dụng quản lý cơ bản
        // => bắt buộc phải cài đặt thành công CRUD
    }
}
