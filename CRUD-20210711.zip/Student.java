/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ctsinhvien;

/**
 *
 * @author hunagroup
 */
public class Student {
    
    // Fields (Info)
    private String id;
    private String name;
    private int age;
    private double math;
    private double english;
    private double informatic;
    
    // Setter & Getter

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getMath() {
        return math;
    }

    public void setMath(double math) {
        this.math = math;
    }

    public double getEnglish() {
        return english;
    }

    public void setEnglish(double english) {
        this.english = english;
    }

    public double getInformatic() {
        return informatic;
    }

    public void setInformatic(double informatic) {
        this.informatic = informatic;
    }
    
    // Constructor
    // 1. Không tham số
    // 2. Đầy đủ tham số

    public Student() {
    }

    public Student(String id, String name, int age, double math, double english, double informatic) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.math = math;
        this.english = english;
        this.informatic = informatic;
    }
    
    // Method thêm vào
    // Tính điểm trung bình
    public double avg(){
        return (this.math+ this.english + this.informatic)/3;
    }
    
    // Hiển thị thông tin sinh viên
    public void display(){
        System.out.format("Tên: %s, tuổi: %d, điểm trung bình: %f \n",
                this.name, this.age, this.avg());
    }
    
    // Khi so sánh chủ thể sinh viên A với sinh viên B
    // --> A là this và B là stu
    public int rank(Student stu){
        if(this.avg() > stu.avg()){
            return 1;
        }
        if(this.avg() == stu.avg()){
            return 0;
        }
        return -1;
    }
    
}
