/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ctsinhvien;

import java.util.Scanner;

/**
 *
 * @author hunagroup
 */
public class StudentManagementSystem {
    public static void main(String[] args) {
        //Chương trình Menu quản lý sinh viên
        //Người dùng chọn 1 --> Thêm một sinh viên
        //Người dùng chọn 2 --> Hiện danh sách sinh viên
        //Người dùng chọn 3 --> Hiện thông tin của sinh viên
        //Người dùng chọn 4 --> Cập nhật thông tin sinh viên
        //Người dùng chọn 5 --> Xóa sinh viên
        //Người dùng nhập số khác --> Thoát
        
        StudentManager lophoc = new StudentManager();
        
        Scanner sc = new Scanner(System.in);
        
        int userChoice;
        
        do{
            // Menu
            System.out.println("1- Thêm sinh viên vô lớp");
            System.out.println("2- Liệt kê danh sách sinh viên");
            System.out.println("3- Xem sinh viên");
            System.out.println("4- Cập nhật sinh viên");
            System.out.println("5- Xóa sinh viên");
            System.out.println("Số khác - Thoát");
            // Người dùng nhập tùy chọn chức năng thực hiện
            userChoice = Integer.parseInt(sc.nextLine());
            
            // Dựa trên chọn lựa của người dùng nhập
            // --> Thực thi các chức năng trên lophoc
            switch(userChoice){
                case 1: lophoc.create();break;
                case 2: lophoc.read();break;
                case 3: lophoc.details();break;
                case 4: lophoc.update();break;
                case 5: lophoc.delete();break;
                default: System.out.println("Bye!");
            }           
        }while(userChoice > 0 && userChoice < 6);     
    }
}

// Tóm tắt phương pháp xây dựng ứng dụng CRUD (Ứng dụng quản lý)
// Bước 1: Tạo lớp đối tượng (Student)
// Bước 2: Tạo lớp quản lý đối tượng (StudentManager)
// Bước 3: Chương trình chính Menu, có hàm main (StudentManagementSystem)
