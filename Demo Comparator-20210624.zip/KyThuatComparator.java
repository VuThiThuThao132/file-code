/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kythuatcomparator;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author hunagroup
 */
/*
* Sinh viên thì có {id (duy nhất), name, math, literature}
Tạo ra danh sách (lstSV) 5 sinh viên 
Hãy sử dụng Collection để sắp xếp danh sách đó theo:
Option 1: Sắp xếp tăng dần theo id
Option 2: sắp xếp tăng dần theo math
Option 3: Sắp xếp giảm dần theo điểm literature
Option 4: Sắp xếp tăng dần theo điểm trung bình.
*/
public class KyThuatComparator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        ArrayList<SinhVien> dsSV = new ArrayList<SinhVien>();
        
        dsSV.add(new SinhVien("sv001","An",9,10));
        dsSV.add(new SinhVien("sv004","Bình",9,8));
        dsSV.add(new SinhVien("sv002","Cường",7,8));
        dsSV.add(new SinhVien("sv005","Duy",8,8));
        dsSV.add(new SinhVien("sv003","Phước",9,10));
        dsSV.add(new SinhVien("sv001","Huy",7,10));
        
        // Xuất danh sách các sinh viên
        for(SinhVien item :dsSV){
            System.out.println(item);
        }
        
        // Xuất ra màn hình các sinh viên bằng 
        // với sinh viên cho trước
        
        SinhVien svLong = new SinhVien("sv001","Long",7,7);
        System.out.println("Xuất danh sách sinh viên bằng với svLong");
        
        for(SinhVien item :dsSV){
            if(item.equals(svLong)){
                System.out.println(item);
            }
        }
        
        // Sắp xếp tăng dần dsSV theo mã số (id)
        System.out.println("Sắp xếp danh sách theo id");
        Collections.sort(dsSV);
        for(SinhVien item :dsSV){
            System.out.println(item);
        }
        
        // Sắp xếp danh sách sinh viên tăng dần theo điểm math
        System.out.println("Sắp xếp danh sách tăng dần theo math");
        Collections.sort(dsSV,SinhVien.compareMath);
        for(SinhVien item :dsSV){
            System.out.println(item);
        }
        
        // Sắp xếp danh sách sinh viên giảm dần theo điểm liturature
        System.out.println("Sắp xếp sinh viên giảm dần theo liturature");
        Collections.sort(dsSV,SinhVien.compareLiturature);
        Collections.reverse(dsSV);
        for(SinhVien item :dsSV){
            System.out.println(item);
        }
    }
    
}
