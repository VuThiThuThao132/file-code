/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kythuatcomparator;

import java.util.Comparator;
import java.util.Objects;

/**
 *
 * @author hunagroup
 */
public class SinhVien implements Comparable{
    private String id;
    private String name;
    private double math;
    private double literature;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getMath() {
        return math;
    }

    public void setMath(double math) {
        this.math = math;
    }

    public double getLiterature() {
        return literature;
    }

    public void setLiterature(double literature) {
        this.literature = literature;
    }

    public SinhVien() {
    }

    public SinhVien(String id, String name, double math, double literature) {
        this.id = id;
        this.name = name;
        this.math = math;
        this.literature = literature;
    }

    @Override
    public String toString() {
        return "SinhVien{" + "id=" + id + ", name=" + name + ", math=" + math + ", literature=" + literature + '}';
    }
    
    // Làm sao để biết 2 đối tượng có bằng (giống) nhau không
    @Override
    public boolean equals(Object obj) {       
        SinhVien temp = (SinhVien)obj;    
        return this.id.equals(temp.id);
    }
    
    //Định nghĩa phép so sánh 2 sinh viên dựa trên id
    // Khai báo hàm này để tạo ra phép so sánh 2 sinh viên
    // dựa trên id
    // this so sánh với o
    // Nếu kết quả là 1 thì this > o
    // Nếu kết quả là 0 thì this = o
    // Nếu kết quả là -1 thì this < o
    @Override
    public int compareTo(Object o) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        SinhVien temp = (SinhVien)o;
     
        return this.id.compareTo(temp.id);
    }
    
    // Định nghĩa ra phép so sánh khác của 2 sinh viên
    // -1 nếu obj1 có điểm toán nhỏ hơn điểm toán obj2
    // 0: -1 nếu obj1 có điểm toán bằng điểm toán obj2
    // 1 nếu obj1 có điểm toán lớn hơn điểm toán obj2
    // Ví dụ: math
    public static Comparator compareMath = new Comparator(){
        @Override
        public int compare(Object obj1, Object obj2){
            SinhVien sv1 = (SinhVien)obj1;
            SinhVien sv2 = (SinhVien)obj2;
            
            if(sv1.math > sv2.math){
                return 1;
            }
            else if(sv1.math == sv2.math){
                return 0;
            }
            else{
                return -1;
            }
        }
    };
    
    public static Comparator compareLiturature = new Comparator(){
        @Override
        public int compare(Object obj1, Object obj2){
            SinhVien sv1 = (SinhVien)obj1;
            SinhVien sv2 = (SinhVien)obj2;
            
            if(sv1.literature > sv2.literature){
                return 1;
            }
            else if(sv1.literature == sv2.literature){
                return 0;
            }
            else{
                return -1;
            }
        }
    };
}
