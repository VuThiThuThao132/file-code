/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import com.sun.tools.javac.Main;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class FoodList extends ArrayList< food > {
   private static Scanner sc = new Scanner(System.in);
    
   //Xoa theo Id 
   public void removeFood(){
        Inputter in = new Inputter();
        if (this.isEmpty()) {
            System.out.println("Empty list. No remove update can be perdorm");
        } else {
            String rCode = in.inputPattern("Input code of removed food :","[S][\\d]{2}");
            food st = this.search(rCode);//search Food
            if (st == null) {
                System.out.println("Food " + rCode + " doesn't existed!");
            }
            if (askUser(" remove").matches("Y")) {
                this.remove(st);//remove this Food
                System.out.println("Food " + rCode + " has been removed");
                System.out.println("------------- ------------------List---------------------------------------");
                System.out.println("ID  Name           Weight         Type      Place      Expireddate");
                for (food op : this) {
                    op.display();
                }

            } else {
                System.out.println("Removed fail");

            }
        }
    }
   
    //lưu File
    public void storeList() {
        String nameF = "";
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter name of File");
        nameF = sc.nextLine();
        System.out.println("Bat dau luu");
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(nameF + ".txt");
            String line = null;
            for (food std : this) {
                line = std.getLine();
                byte[] b = line.getBytes("utf8");
                fos.write(b);
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void addFood (){
    String ID ;
    String NewFoodName ;
    String NewType;
    String Place;
    float NewWeight ;
    String NewExpiredDate ;
    boolean codeDuplicated=false;
   
    do{
            ID = Inputter.inputPattern("St. code S00: ","[S][\\d]{2}");
            ID = ID.trim().toUpperCase();
            codeDuplicated = isCodeDupplicated(ID);
            if (codeDuplicated)System.out.println(" Code is duplicated! ");
        }    
        while (codeDuplicated==true);
        NewFoodName = Inputter.inputStr("Name of new Food : ");
        NewType = Inputter.inputStr("Name of new Type : ");
        Place = Inputter.inputPattern("Choose 1 to put Freezer or 2 to put Cooler: ", "[1-2]");
        if(Place.equals("1")){
            Place = "Freezer";
        }
        if(Place.equals("2")){
            Place = "Cooler";
        }
        NewWeight = Inputter.inputInt("New Weight : ", 0, 200);
        int newDays = 0, newYear = 0, newMonth = 0;
        do {
            //Expireddate
            NewExpiredDate = Inputter.inputPattern("New expireddate: ", "[\\d]{1,2}[/][\\d]{1,2}[/][0-9]+");
            //tách ngày tháng năm
            String[] params = NewExpiredDate.split("/");

            try {
                newDays = Integer.parseInt(params[0]);
                newMonth = Integer.parseInt(params[1]);
                newYear = Integer.parseInt(params[2]);
            } catch (ArrayIndexOutOfBoundsException ex) {
            } finally {
            }
        } while (!checkDate(newDays, newMonth, newYear));
        
        food f = new food (ID,NewFoodName,NewType,Place,NewWeight,NewExpiredDate ) ;
        this.add(f);
        System.out.println("-------------------------------List---------------------------------------");
        System.out.println("ID  Name           Weight         Type      Place      Expireddate");
        for (food op : this) {
            op.display();
        }
        System.out.println("Products " + ID + " has been added. ");
    }
    
    //Tim kiem học sinh
    public void searchFood(){
       boolean flag = true;
        if (this.isEmpty()) {
            System.out.println("Empty list. No search can be perform!");
        } else {
            Inputter in = new Inputter();
            String sName = in.inputStr("Input name of food for search");
            sName =sName.trim().toUpperCase();
            for (int i = 0; i < this.size(); i++) {
                if (this.get(i).getName().toUpperCase().contains(sName)) {
                    while (flag == true) {
                        System.out.println("-------------------------------List---------------------------------------");
                        System.out.println("ID  Name           Weight         Type      Place      Expireddate");
                        flag = false;
                    }

                    this.get(i).display();

                }
            }
                if (flag == true) {
                    System.out.println("Does not exist!!!!");
                }
            
        }
    }
    
    //kiem tra ID
    public food search(String code){
        code =code.trim().toUpperCase();
        for (int i=0;i<this.size();i++)
            if (this.get(i).getID().equals(code)) return this.get(i);
        return null;
    }
    
    //Kiem tra trung
    private boolean isCodeDupplicated (String bID){
        bID =bID.trim().toUpperCase();
        return searchID (bID) != null;
        
    }
    
    //Tim kiem theo ID viet thuong va hoa
    public food searchID(String s){
      //code =code.trim().toUpperCase();
      // for (int i=0;i<this.size();i++) 
       s = s.trim().toUpperCase();
        for (int i=0;i<this.size();i++)
            if (this.get(i).getID().equalsIgnoreCase(s)) return this.get(i);
            return null;
}
    
    //hoi nguoi dung
    public String askUser(String a) {
        String answer = "";
        int flag = 0;
        do {
            System.out.println("Do you want to" + a + "???(Y/N)");
            Scanner sc = new Scanner(System.in);
            answer = sc.nextLine();
            if (answer.matches("Y")) {
                flag = 0;
            } else if (answer.matches("N")) {
                flag = 0;
            } else {
                System.out.println("Please enter correct Y/N");
                flag = 1;
            }
        } while (flag != 0);
        return answer;
    }
    
    //nhap vao 1 so thuc 

    
    //Chuyen String thanh ngay
    public long changeDay(String a) {
        long b = 0;
        Calendar c = Calendar.getInstance();
        int newDays = 0, newYear = 0, newMonth = 0;
        String[] params = a.split("/");
        try {
            newDays = Integer.parseInt(params[0]);
            newMonth = Integer.parseInt(params[1]);
            newYear = Integer.parseInt(params[2]);
        } catch (ArrayIndexOutOfBoundsException ex) {
        } finally {
        }
        c.set(newYear, newMonth - 1, newDays);
        b = c.getTimeInMillis();
        b = b / (86400000);
        return b;
    }
    
    //Sap xep theo thu tu ngay giam dan 
    public void arrange(){
               if (this.isEmpty()) {
            System.out.println("Empty list!");
        } else {
            Collections.sort(this, new Comparator<food>() {
                @Override
                public int compare(food op1, food op2) {
                    if (changeDay(op1.getExpireddate()) > changeDay(op2.getExpireddate())) {
                        return -1;
                    }
                    return 1;
                }
            }
            );
    }
    }
    
    //Kiem tra han su dung
    public boolean checkYear(int year) {
        boolean isLeap = false;
        if (year % 4 == 0)//chia hết cho 4 là năm nhuận
        {
            if (year % 100 == 0) //nếu vừa chia hết cho 4 mà vừa chia hết cho 100 thì không phải năm nhuận
            {
                if (year % 400 == 0)//chia hết cho 400 là năm nhuận
                {
                    isLeap = true;
                } else {
                    isLeap = false;//không chia hết cho 400 thì không phải năm nhuận
                }
            } else//chia hết cho 4 nhưng không chia hết cho 100 là năm nhuận
            {
                isLeap = true;
            }
        } else {
            isLeap = false;
        }
        return isLeap;
    }
    
   //Kiem tra nam nhuan 
    public boolean checkDate(int day, int month, int year) {
        boolean flag = true;
        Calendar c = Calendar.getInstance();
        int nyear = c.get(Calendar.YEAR);
        int nmonth = c.get(Calendar.MONTH);
        int nday = c.get(Calendar.DAY_OF_MONTH);

        if (day <= nday) {
            if (month <= nmonth + 1) {
                if (year <= nyear) {

                    flag = false;
                }
            }
        }

        if (year == 0) {
            flag = false;
        }

        if (day > 31) {
            flag = false;
        }
        if (month == 4 || month == 6 || month == 9 || month == 11) {
            if (day > 30) {
                flag = false;
            }
        }
        if (checkYear(year)) {
            if (month == 2 && day > 29) {
                flag = false;
            }
        } else {
            if (month == 2 && day > 28) {
                flag = false;
            }
        }
        if (month < 0 || month > 12) {
            flag = false;
        }
        return flag;
    }   
    
}


