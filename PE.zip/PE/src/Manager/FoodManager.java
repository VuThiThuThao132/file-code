package Manager;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class FoodManager {

    public static Scanner in = new Scanner(System.in);

    public static void main(String[] args) {

         String[] options = {"Add a new food", "Search a food by name", "Remove the food by ID",
             "Print the food list in the descending order of expired date", "Save", "Quit"};

        int Choice = 0;
        FoodList list = new FoodList();
        do {   
            Choice = Menu.getChoice(options);
             switch (Choice) {
                case 1 :
                    do {
                        list.addFood();
                    } while (list.askUser(" continue").matches("Y"));
                    break;
                case 2 :
                    do {
                        list.searchFood();
                    } while (list.askUser(" continue").matches("Y"));
                    break;
                case 3 :
                    list.removeFood();
                    break;
                case 4 :
                    list.arrange();
                    break;
                case 5 :
                    list.storeList();
                    break;
                case 6 :
                    System.out.println("Bye!");
                    break;
                default:
                    System.out.println("Enter number 1..6");
                    break;
            }
        } while ((Choice > 0 && Choice < 6));

    }
}
