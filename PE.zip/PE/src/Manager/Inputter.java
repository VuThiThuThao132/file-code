/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Inputter {
    public static Scanner sc = new Scanner(System.in);
    /**
     * @param args the command line arguments
     */
    public static int getAnInteger(String inputMsg, String errorMsg) {
        int n;
        
        while (true) {
            try {
                System.out.print(inputMsg);
                n = Integer.parseInt(sc.nextLine()); //sống ko để lại rác
                return n;
            } catch (Exception e) {
                System.out.println(errorMsg);
            }
        }
    }
    
    
    
    
    
    
    
 public static float inputInt(String msg, long min, long max) {
        String flag = "";
        if (min > max) {
            long t = min;
            min = max;
            max = t;
        }
        float data;
        do {

            do {
                flag = inputPattern(msg, "([\\d]+[.][\\d]+)|([\\d]+)");
            } while (Float.parseFloat(flag) <= 0);

            data = Float.parseFloat(flag);

        } while (data < min || data > max);
        return data;
    }
    
    public static String inputStr(String msg){
        boolean flag = true;
        String data = "";
        do {
                System.out.println(msg);
                data = sc.nextLine().trim();
            if (data.matches("([0-9])|((.*)[0-9]+)|((.*)[0-9]+(.*))")) {
                System.out.println("Please no enter number!");
                flag = true;
            } else if (data.contains("-")) {
                System.out.println("Please no enter negative number!");
                flag = true;
            } else if (data.length() == 0) {
                System.out.println("Please no blank!");
                flag = true;
            } else {

                flag = false;
            }
            
        } while (flag == true);

        return data;
    }
    public static String inputNonBlankStr (String msg){
        String  data;
        do{
            System.out.print(msg);
            data=sc.nextLine().trim();
          }
        while (data.length()==0);
        return data;
    }
    public static String inputPattern (String msg,String pattern){
        String data;
        boolean flag = true;
        do{
            
            System.out.print(msg);
            data =sc.nextLine().trim();
            flag = data.matches(pattern);
            if (flag == false){
                System.out.println("Please enter correct format");
            }
         }
        while (flag == false);
        return data;
    }
    public static double getADouble(String inputMsg, String errorMsg) {
        double n;
        
        while (true) {
            try {
                System.out.print(inputMsg);
                n = Double.parseDouble(sc.nextLine());
                return n;
            } catch (Exception e) {
                System.out.println(errorMsg);
            }
        }
    }
    
}
