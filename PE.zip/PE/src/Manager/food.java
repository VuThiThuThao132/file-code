/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Manager;

/**
 *
 * @author ASUS
 */
public class food  {

    private String ID,Name,Type, expireddate,place;
    private float weight ;


    public food()  {
    }

    public food(String ID, String Name, String Type, String place, float weight, String expireddate) {
        this.ID = ID;
        this.Name = Name;
        this.Type = Type;
        this.place = place;
        this.expireddate = expireddate;
        this.weight = weight;
    }
    
    
    
    

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getExpireddate() {
        return expireddate;
    }

    public void setExpireddate(String expireddate) {
        this.expireddate = expireddate;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public String toString() {
        return "Id: " + ID + ", Name: " + Name + ", Weight: " + weight + "kg" + ", Type " + Type + ", Place: " + place + ", Expireddate: " + expireddate;
    }

    public String getLine() {
        return ID + ", " + Name+ ", " + weight + ", " + Type + ", " + place + ", " + expireddate +"\n";
    }

    public void display() {
        
        System.out.printf("%s %-14s %-9.2f(kg)  %-9s %-10s %-8s \n",ID,Name,weight,Type,place,expireddate);
    }
    }
